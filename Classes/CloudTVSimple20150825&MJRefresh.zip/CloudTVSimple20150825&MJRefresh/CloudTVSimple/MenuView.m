//
//  MenuView.m
//  CloudTvSimple
//
//  Created by Hu on 06/02/15.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "MenuView.h"
#import "Constant.h"
#import "RegexKitLite.h"
#import "MenuItem.h"

@implementation MenuView
@synthesize IPField,IPSaveBtn,scrollView,delegate;
static  int NumMenuItem=7;
static int rowWidthMenu = 228;


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}
-(void)loadMenuItem
{
    self.IPField.delegate=self;
      
    NSArray *arrUnselectImage =[NSArray arrayWithObjects:@"base_ziliao_unselected.png", @"shoucang_unselected.png",@"message_unselect.png",
                                @"histort_task_unselected.png", @"un_do_task_unselected.png", @"qiandao_unselected.png",@"search_unselected.png", nil];
    NSArray *arrName =[NSArray arrayWithObjects:@"基本资料",@"收    藏",@"消    息",@"历史任务",@"未完成任务",@"签    到",@"搜    索", nil];
    if(self.scrollView != nil){
        NSArray *subviews =[self.scrollView subviews];
        for (int i = 0, l = [subviews count]; i < l; i++){
            UIView* MenuItem = [subviews objectAtIndex:i];
            [MenuItem removeFromSuperview];
        }
        for(int i=0; i<NumMenuItem;i++)
        {
            NSArray *nibContents = [[NSBundle mainBundle] loadNibNamed:@"MenuItem"
                                                                 owner:self
                                                               options:nil];
            
            __weak MenuItem *myView = [nibContents objectAtIndex:0];
           
           
            
            [myView.imageleftView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@",[arrUnselectImage objectAtIndex: i] ]]];
            [myView.MiddleName setText:[NSString stringWithFormat:@"%@",arrName[i]]];
            myView.frame = CGRectMake(0, (self.frame.size.height-216)/NumMenuItem * i, rowWidthMenu, (self.frame.size.height-216)/NumMenuItem);
            
            __weak MenuView *weakSelf= self;
            myView.tag=i;
            myView.onMenuItemTapListener = ^(UIView* view){
                
                
                [weakSelf onMenuItemTap:view];
            };
            
            
            
            
            [self.scrollView addSubview:myView];
            
            
            [self checkScrollViewHeight];
        
        
        }
    }
    
}

//点击return 按钮 去掉
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
//点击屏幕空白处去掉键盘
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.IPField resignFirstResponder];
    
}
-(void)onMenuItemTap:(UIView *)view
{
    
    
    NSArray *arrUnselectImage =[NSArray arrayWithObjects:@"base_ziliao_unselected.png", @"shoucang_unselected.png",@"message_unselect.png",
                                @"histort_task_unselected.png", @"un_do_task_unselected.png", @"qiandao_unselected.png",@"search_unselected.png", nil];
    
    NSArray* subviews = [self.scrollView subviews];
    for (int i = 0, l = [subviews count]; i < l; i++){
        UIView *subview = [subviews objectAtIndex:i];
        if ([subview class] == [MenuItem class]){
            MenuItem *MenuItemAll = (MenuItem*) subview;
            [MenuItemAll.imageleftView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@",[arrUnselectImage objectAtIndex:i]]]];
            [MenuItemAll.BgView setBackgroundColor: [UIColor whiteColor]];
            [MenuItemAll.imagerightView setHidden: YES];
        }
    }
  
    NSArray *arrselectImage =[NSArray arrayWithObjects:@"base_ziliao_selected.png", @"shoucang_selected.png",@"message_select.png",
                                @"histort_task_selected.png", @"un_do_task_selected.png", @"qiandao_selected.png",@"search_selected.png", nil];
    
     MenuItem *menuitem = (MenuItem*) view;
     if ([view class] == [MenuItem class]){
         
        
         
         [menuitem.imageleftView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@",[arrselectImage objectAtIndex:menuitem.tag]]]];
         [menuitem.BgView setBackgroundColor:[UIColor colorWithRed:0.5 green:0.5 blue:0.5 alpha:0.5]];
         [menuitem.imagerightView setHidden: NO];
     }
   
    
}
-(void)checkScrollViewHeight{
    if(self.scrollView != nil){
		NSArray *Subviews = [self.scrollView subviews];
		CGFloat totalHeight = 0;
		for (int i = [Subviews count] - 1; i >= 0; i--){
			UIView* view = [Subviews objectAtIndex:i];
			if (! view.hidden){
                
				totalHeight += view.frame.size.height;
			}
		}
		
		if (totalHeight < self.scrollView.frame.size.height){
			totalHeight = self.scrollView.frame.size.height;
		}
		
        [self.scrollView setContentSize:CGSizeMake(rowWidthMenu, totalHeight)];
    }
}
- (IBAction)saveIPAction:(id)sender
{
    
    NSArray *array = [[IPField text]  componentsSeparatedByString:@":"];
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];

    NSString *regex = @"\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b";
    NSString *InputIP= [NSString stringWithFormat:@"%@",array[0]];
    NSLog(@"Regex: %@", regex);
    if([ InputIP isMatchedByRegex:regex]){
        NSLog(@"Valid IP address");
        [userDefault setObject:[IPField text] forKey: @"BaseIP"];
        [Constant setBaseIP:[IPField text]];
        [self.delegate ReloadMainView];
        
    }
    else
    {
     
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示"
                                           message:@"IP地址格式错误"
                                          delegate:self
                                 cancelButtonTitle:@"知道了"
                                 otherButtonTitles:nil];
        [alert show];
        
    }
    

}

-(void)updateIpEdittext
{

    [IPField  setText:[Constant getOnlyBaseIP]];

}

@end
