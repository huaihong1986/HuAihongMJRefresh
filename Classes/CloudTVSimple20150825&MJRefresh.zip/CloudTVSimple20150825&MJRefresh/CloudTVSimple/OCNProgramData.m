//
//  OCNProgramData.m
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import "OCNProgramData.h"

@implementation OCNProgramData

@synthesize programID;
@synthesize fullTitle;
@synthesize updatedAt;
@synthesize broadcastStartAt;
@synthesize broadcastEndAt;
@synthesize description;

- (NSString *)getFormattedBroadcastStartAt {
    NSRange range= NSMakeRange(11, 5);
    return [self.broadcastStartAt substringWithRange:range];
    
    NSString *cleanDate = [self.broadcastStartAt substringWithRange:NSMakeRange(0, 19)];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSDate *theDate = [dateFormatter dateFromString:cleanDate];
    [dateFormatter setDateFormat:@"HH:mm"];
    
    return [dateFormatter stringFromDate:theDate];
}

- (NSString *)getBroadcastDate {
    
    return [self.broadcastStartAt substringToIndex:10];
    
    NSString *cleanDate = [self.broadcastStartAt substringWithRange:NSMakeRange(0, 19)];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSDate *theDate = [dateFormatter dateFromString:cleanDate];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    return ([dateFormatter stringFromDate:theDate]);
}

- (BOOL)isBroadcastOn: (NSString*) date {
    NSString *cleanDate = [self.broadcastStartAt substringWithRange:NSMakeRange(0, 19)];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSDate *theDate = [dateFormatter dateFromString:cleanDate];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    return ([date isEqualToString:[dateFormatter stringFromDate:theDate]]);
}

- (BOOL)isInComingDays {
    NSString *cleanDate = [self.broadcastStartAt substringWithRange:NSMakeRange(0, 19)];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSDate *theDate = [dateFormatter dateFromString:cleanDate];
    NSDate *earlierBound = [[NSDate date] dateByAddingTimeInterval:(-86400)];
    NSDate *laterBound = [[NSDate date] dateByAddingTimeInterval:(86400 * 8)];
    
    if ([theDate compare:earlierBound] == NSOrderedAscending)
        return NO;
    
    if ([theDate compare:laterBound] == NSOrderedDescending) 
        return NO;
    
    return YES;
}

- (BOOL)isBroadcasting {
    NSString *cleanStartDate = [self.broadcastStartAt substringWithRange:NSMakeRange(0, 19)];
    NSString *cleanEndDate = [self.broadcastStartAt substringWithRange:NSMakeRange(0, 19)];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSDate *startDate = [dateFormatter dateFromString:cleanStartDate];
    NSDate *endDate = [dateFormatter dateFromString:cleanEndDate];
    NSDate *nowDate = [NSDate date];
	
    if ([nowDate compare:startDate] == NSOrderedAscending)
        return NO;
    
    if ([nowDate compare:endDate] == NSOrderedDescending) 
        return NO;
    
    return YES;
}

@end
