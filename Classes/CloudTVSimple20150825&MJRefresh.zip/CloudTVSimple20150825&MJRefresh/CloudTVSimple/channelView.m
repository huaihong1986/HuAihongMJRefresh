//
//  channelView.m
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import "channelView.h"
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"
#import "SBJson.h"
#import "MainViewController.h"
@implementation channelView

@synthesize channelLabel=_channelLabel;
@synthesize watchingLabel=_watchingLabel;
@synthesize willWatchLabel=_willWatchLabel;

@synthesize watchingMarqueeLabel=_watchingMarqueeLabel;
@synthesize willWatchMarqueeLabel=_willWatchMarqueeLabel;
@synthesize watchingLabelContainer=_watchingLabelContainer;
@synthesize willWatchLabelContainer=_willWatchLabelContainer;
@synthesize channelData;
@synthesize onChannelViewTapListener;


- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        
        // Initialization code
    }
    return self;
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
	if (self.onChannelViewTapListener) {
		self.onChannelViewTapListener(self);
	}
}

- (void)setWatchingText: (NSString *)str {
	if (self.watchingMarqueeLabel == nil) {
		CGRect frame = CGRectMake(0, 0, self.watchingLabelContainer.frame.size.width, self.watchingLabelContainer.frame.size.height);
		self.watchingMarqueeLabel = [[MarqueeLabel alloc] initWithFrame:frame rate:10 andFadeLength:0.0];
		self.watchingMarqueeLabel.textAlignment = UITextAlignmentCenter;
		self.watchingMarqueeLabel.textColor = [UIColor colorWithRed:0.96 green:0.4 blue:0.21 alpha:1];
		self.watchingMarqueeLabel.marqueeType = MLContinuous;
        self.watchingMarqueeLabel.font= [UIFont fontWithName:@"Helvetica" size:13.0];
		
		[self.watchingLabelContainer addSubview:self.watchingMarqueeLabel];
	}
	
	self.watchingMarqueeLabel.text = str;
}


- (void)setWillWatchText: (NSString *)str {
	if (self.willWatchMarqueeLabel == nil) {
		CGRect frame = CGRectMake(0, 0, self.willWatchLabelContainer.frame.size.width, self.willWatchLabelContainer.frame.size.height);
		self.willWatchMarqueeLabel = [[MarqueeLabel alloc] initWithFrame:frame rate:10 andFadeLength:0.0];
		self.willWatchMarqueeLabel.textAlignment = UITextAlignmentCenter;
		self.willWatchMarqueeLabel.textColor = [UIColor colorWithRed:0.96 green:0.4 blue:0.21 alpha:1];
		self.willWatchMarqueeLabel.marqueeType = MLContinuous;
        self.willWatchMarqueeLabel.font= [UIFont fontWithName:@"Helvetica" size:13.0];
		
		[self.willWatchLabelContainer addSubview:self.willWatchMarqueeLabel];
	}
	
	self.willWatchMarqueeLabel.text = str;
    
}













@end
