    //
//  VideoDataItem.m
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import "VideoDataItem.h"

@implementation VideoDataItem

@synthesize cid,cont_column,cont_program,cont_tvseries_id,description,picUrl,playUrl;

- (NSString*)getcid {
    return self.cid;
}

- (NSString *)getcont_column {
    return self.cont_column;
}

- (NSString *)getcont_program {
    return self.cont_program;
}

- (NSString *)getcont_tvseries_id {
    return self.cont_tvseries_id;
}

- (NSString *)getdescription {
    return self.description;
}

-(NSString *)getpicUrl {
    return self.picUrl;
}

- (NSString *)getplayUrl {
    return self.playUrl;
}



@end
