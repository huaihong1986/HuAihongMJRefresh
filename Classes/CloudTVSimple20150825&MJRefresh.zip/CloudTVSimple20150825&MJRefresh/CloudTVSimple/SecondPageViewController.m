//
//  SecondPageViewController.m
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import "SecondPageViewController.h"
#import <MediaPlayer/MediaPlayer.h>
#import "AppDelegate.h"
#import "OCNChannelProgramData.h"
#import "MBProgressHUD.h"
#import "MainViewController.h"

@implementation SecondPageViewController
@synthesize switchBtn=_switchBtn;
@synthesize nameLabel=_nameLabel;

@synthesize channelNameLabel;

@synthesize channelData, channelURL, channelID;
@synthesize isAppearing;
@synthesize playerView;
@synthesize playerViewContainer;
@synthesize player;
@synthesize playerItem;

@synthesize onPushBtnTapListener;
@synthesize onFinishPushBtnTapListener;

@synthesize soundOnBtn, soundOffBtn;
@synthesize volumeBarBG, volumeBar, volumeBarThumb, volumeToucher;
@synthesize  fullPanelTimer;
@synthesize playBtn, pauseBtn;

@synthesize ctrlPanel, topPanel;
@synthesize isShowPanel;
@synthesize switchPushBtn;

@synthesize fileURL, playerViewController;



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}


- (IBAction)BackBtn:(id)sender {
    [self.player pause];
   
    
   
    [self.navigationController popToRootViewControllerAnimated:YES];
     self.firstPageViewController.currentSecondPageViewController = nil;
    [self.player replaceCurrentItemWithPlayerItem:nil];
}

- (void)showSoundOn{
    if (! soundOn){
        [self.soundOnBtn setHidden:NO];
        [self.soundOffBtn setHidden:YES];
        soundOn = YES;
    }
}

- (void)showSoundOff{
    if (soundOn){
        [self.soundOffBtn setHidden:NO];
        [self.soundOnBtn setHidden:YES];
        soundOn = NO;
    }
}

static const NSString *ItemStatusContext;


- (IBAction)onTapPlayPauseBtn:(id) sender {
    if (showPlaying) {
        if (stopped) {
			[self loadVideoFromURL];
			stopped = NO;
		}
        else {
			[self.player play];
		}
    }
    else {
        [self.player pause];
    }
	
	[self hasActivity];
}

- (IBAction)onTapStopBtn:(id) sender{
	
	[self.player pause];
	stopped = YES;
	[self hasActivity];
}

- (void)hasActivity{
	
    if (self.fullPanelTimer){
		[self.fullPanelTimer invalidate];
		self.fullPanelTimer = nil;
	}
	
	self.fullPanelTimer = [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(hidePanel) userInfo:nil repeats:NO];
}


- (void)setVolume:(float) volume{
    [AppDelegate setAppVolume:volume];
}

- (void)volumeChanged:(NSNotification *)notification
{
    float volume = [[[notification userInfo] objectForKey: @"AVSystemController_AudioVolumeNotificationParameter"] floatValue];
    
   
    [self syncVolumeUI:volume];
}

- (void)syncVolumeUI:(float) volume{
    
    CGRect barFrame = self.volumeBar.frame;
    CGRect thumbFrame = self.volumeBarThumb.frame;
    
    self.volumeBarThumb.frame = CGRectMake(barFrame.origin.x + self.volumeBarBG.frame.size.width * volume - thumbFrame.size.width / 2, thumbFrame.origin.y, thumbFrame.size.width, thumbFrame.size.height);
    
    self.volumeBar.frame = CGRectMake(barFrame.origin.x, barFrame.origin.y, self.volumeBarBG.frame.size.width * volume, barFrame.size.height);
    
    if (volume == 0){
        [self showSoundOff];
    }else{
        [self showSoundOn];
    }
    
}

- (IBAction)onTapSoundOn:(id)sender{
    prevVolume = [AppDelegate getSystemVolume];
    [self setVolume:0];
}

- (IBAction)onTapSoundOff:(id)sender{
    [self setVolume:prevVolume];
}


//to listen the events from the player
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context{
    if (context == &ItemStatusContext) {
        dispatch_async(dispatch_get_main_queue(),
                       ^{
                           //[self syncUI];
                       });
        return;
    }
    
    if ([keyPath isEqualToString:@"rate"]){
        if ([self.player rate]){
            //[self.playerBtn setShowPlaying:NO];
			showPlaying = NO;
			[self.playBtn setHidden:YES];
			[self.pauseBtn setHidden:NO];
        }else{
            //[self.playerBtn setShowPlaying:YES];
			showPlaying = YES;
			[self.playBtn setHidden:NO];
			[self.pauseBtn setHidden:YES];
        }
        return;
    }
    
    [super observeValueForKeyPath:keyPath ofObject:object
                           change:change context:context];
    return;
}

- (void)hidePanel{
	
	if (self.topPanel.alpha > 0){
		[UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
			self.topPanel.alpha = 0;
			self.ctrlPanel.alpha = 0;
		} completion:^(BOOL finished) {
			
		}];
	}
}

- (void)showPanel{

	self.topPanel.alpha = 1;
	self.ctrlPanel.alpha = 1;
}

- (void)onFullPanelTap:(UITapGestureRecognizer *)recognizer {
	if(self.isShowPanel){
        [self showPanel];
        self.isShowPanel= NO;
	}else{
        [self hidePanel];
        self.isShowPanel= YES;
    }
    
	[self hasActivity];
}

- (void)loadVideoFromURL{
	
	MBProgressHUD* loading = [MBProgressHUD showHUDAddedTo:self.playerView animated:NO];
	
	AVURLAsset *asset = [AVURLAsset URLAssetWithURL:self.fileURL options:nil];
	NSString *tracksKey = @"tracks";
	
	[asset loadValuesAsynchronouslyForKeys:[NSArray arrayWithObject:tracksKey] completionHandler:
	 ^{
		 // The completion block goes here.
		 dispatch_async(dispatch_get_main_queue(),
						^{
							[loading hide:NO];
							NSError *error = nil;
							AVKeyValueStatus status = [asset statusOfValueForKey:tracksKey error:&error];
							
							if (status == AVKeyValueStatusLoaded) {
								//[self.ad setHidden:YES];
                                [self.playerItem removeObserver:self forKeyPath:@"status"];
								self.playerItem = [AVPlayerItem playerItemWithAsset:asset];
								
								if (self.player != nil){
									[self.player replaceCurrentItemWithPlayerItem:self.playerItem];
								}else{
                                    [self.player removeObserver:self forKeyPath:@"rate"];
									self.player = [AVPlayer playerWithPlayerItem:self.playerItem];
									[self.playerView setPlayer:self.player];
									[self.player addObserver:self forKeyPath:@"rate" options:0 context:nil];
								}
								
								[self.playerItem addObserver:self forKeyPath:@"status"
													 options:0 context:&ItemStatusContext];
								[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(movieFinishedCallback:) name:AVPlayerItemDidPlayToEndTimeNotification object:self.playerItem];
								
								
								[self.player play];
								[self hasActivity];
							}
							else {
								// You should deal with the error appropriately.
                                if ([asset.URL isEqual:self.fileURL]) {
                                    
                                    
                                    
                                    
                                    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
                                    NSString * message;
                                    if([[error localizedDescription] isEqualToString:@"The requested URL was not found on this server."]){
                                        
                                        message=@"节目无法播放（E5501）";
                                        if([userDefault objectForKey:@"messages_message"]){
                                            NSDictionary * messageReportDic=[userDefault objectForKey:@"messages_message"];
                                            if([messageReportDic objectForKey:@"E5501"]){
                                                NSDictionary * messageDic=[messageReportDic objectForKey:@"E5501"];
                                                
                                                message=[messageDic objectForKey:@"message"];
                                            }
                                        }
                                        
                                    }else{
                                        message=@"节目无法播放(E5105）";
                                        if([userDefault objectForKey:@"messages_message"]){
                                            NSDictionary * messageReportDic=[userDefault objectForKey:@"messages_message"];
                                            if([messageReportDic objectForKey:@"E5105"]){
                                                NSDictionary * messageDic=[messageReportDic objectForKey:@"E5105"];
                                                
                                                message=[messageDic objectForKey:@"message"];
                                            }
                                        }
                                        
                                    }
                                    
                                    alert = [[UIAlertView alloc] initWithTitle:@"提示"
                                                                       message:message
                                                                      delegate:self
                                                             cancelButtonTitle:@"知道了"
                                                             otherButtonTitles:nil];
                                    [alert show];
                                    alert.tag=10;
                                    
                                   
                                }
							}
						});
	 }];
}

- (void)alertView:(UIAlertView *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    actionSheet.tag=0;
  

    
}

-(void)loadVideo{
    if (self.channelURL){
       
        self.fileURL = [NSURL URLWithString:[channelURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
        [self loadVideoFromURL];
    }else{
        
        NSArray* resources = channelData.resources;
        for (int i = 0, l = [resources count] - 1; i <= l; i++){
            NSDictionary* resource = [resources objectAtIndex:i];
            NSString* type = [resource objectForKey:@"type"];
            if ([type isEqualToString:@"hls"]){
                NSString* url = [resource objectForKey:@"url"];
                
                self.fileURL = [NSURL URLWithString:[url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
                
                [self loadVideoFromURL];
            }
        }
    }
}




- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
	if ([touch.view isKindOfClass:[UIControl class]]) {
		// we touched a button, slider, or other UIControl
		return NO; // ignore the touch
	}
    return YES; // handle the touch
}

- (int)getCurrentChannelID{
    if (self.isAppearing){
        if (self.channelID){
            return [self.channelID intValue];
        }else{
            return [self.channelData.num intValue];
        }
    }else{
        return -1;
    }
}


#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.switchPushBtn.hidden = YES;
    
    switchNum = 0;
    switchPlayAndStopNum = 0;
    prevVolume = [AppDelegate getSystemVolume];
    soundOn = YES;
    self.isAppearing = YES;
    self.isShowPanel= YES;
    
    self.playerView = self.playerViewContainer;
    if (channelData){
        self.channelNameLabel.text = channelData.name;
    }
    
    CGFloat toucherWidth = self.volumeToucher.frame.size.width;
    __weak SecondPageViewController *s=self;
    self.volumeToucher.movedHandler = ^ (UIEvent* event, CGPoint point){
        float pc = point.x / toucherWidth;
        if (pc < 0){
            pc = 0;
        }else if (pc > 1){
            pc = 1;
        }
        [s setVolume:pc];
    };
    
    [[NSNotificationCenter defaultCenter]
     addObserver:self
     selector:@selector(volumeChanged:)
     name:@"AVSystemController_SystemVolumeDidChangeNotification"
     object:nil];
    
    [self loadVideo];

	
	
	UITapGestureRecognizer *singleFingerTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onFullPanelTap:)];
	singleFingerTap.delegate = self;
    [self.view addGestureRecognizer:singleFingerTap];
   
}


- (IBAction)onTapPushBtn:(id) sender{
    
    if (self.onPushBtnTapListener){
        self.onPushBtnTapListener();
        
        //[self.player pause];
    }
}

- (IBAction)onTapFullScreen:(id)sender{
    [self.player pause];
    self.playerViewController = [[MPMoviePlayerViewController alloc] initWithContentURL:self.fileURL];
    MPMoviePlayerController *fPlayer = [self.playerViewController moviePlayer];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(movieFinishedCallback:) name:MPMoviePlayerPlaybackDidFinishNotification object:fPlayer];
    [fPlayer play];
    
    [self presentModalViewController:self.playerViewController animated:NO];
}

- (void)movieFinishedCallback:(NSNotification*) aNotification {
    MPMoviePlayerController *fPlayer = [aNotification object];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:fPlayer];
    
    [fPlayer stop];
    
    [self.playerViewController dismissModalViewControllerAnimated:NO];
    
    // call autorelease the analyzer says call too many times
    // call release the analyzer says incorrect decrement
    
    [self loadVideo];
}

- (void)viewDidUnload
{
    [self setNameLabel:nil];
    [self setSwitchBtn:nil];
    [self setSwitchPushBtn:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft || interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskLandscape;
}


- (void)viewWillAppear:(BOOL)animated{
    //set statusbar to the desired rotation position
    
    [[UIApplication sharedApplication] setStatusBarOrientation:UIInterfaceOrientationLandscapeLeft animated:NO];
    self.isAppearing = YES;
    
    //present/dismiss viewcontroller in order to activate rotating.
    UIViewController *mVC = [[UIViewController alloc] init];
    [self presentModalViewController:mVC animated:NO];
    [self dismissModalViewControllerAnimated:NO];
   
    [super viewWillAppear:animated];
	[self.player play];
}

- (void)viewWillDisappear:(BOOL)animated{
    self.isAppearing = NO;

	[self.player pause];
    
    
    if(alert.tag==10)
    {
        
        [alert dismissWithClickedButtonIndex:0 animated:YES];
        alert.tag=0;
        
    }
}

-(void)dealloc{
   
    [self.playerItem removeObserver:self forKeyPath:@"status"];
    [self.player removeObserver:self forKeyPath:@"rate"];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end
