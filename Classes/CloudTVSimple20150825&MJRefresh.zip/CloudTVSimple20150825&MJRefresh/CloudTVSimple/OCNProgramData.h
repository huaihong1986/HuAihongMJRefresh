//
//  OCNProgramData.h
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OCNProgramData : NSObject
@property (nonatomic) NSString *chanelID;
@property (nonatomic) NSString *programID;
@property (nonatomic) NSString *fullTitle;
@property (nonatomic) NSString *updatedAt;
@property (nonatomic) NSString *broadcastStartAt;
@property (nonatomic) NSString *broadcastEndAt;
@property (nonatomic) NSString *description;

- (NSString *)getFormattedBroadcastStartAt;
- (NSString *)getBroadcastDate;
- (BOOL)isBroadcastOn: (NSString *) date;
- (BOOL)isBroadcasting;
- (BOOL)isInComingDays;

@end
