//
//  Constant.m
//  CloudTvSimple
//
//  Created by Hu on 06/02/15.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Constant.h"


@implementation Constant

static NSString *BASE_IP = @"27.115.50.133:8082";

+ (void) setBaseIP:(NSString *)IP {
    BASE_IP = IP;
}

+ (NSString *) getOnlyBaseIP {
    return  BASE_IP;
}

+ (NSString *) getBaseIP {
    return [@"http://" stringByAppendingString: BASE_IP];
}

+ (NSString *) getCloudTviCategory_URL {
    return [[@"http://" stringByAppendingString: BASE_IP] stringByAppendingString: @"/simple/info/column.json"];
}
+ (NSString *) getTELEPLAY_SERIES_URL {
     return [[@"http://" stringByAppendingString: BASE_IP] stringByAppendingString: @"/simple/info/tvseries:"];
}
+ (NSString *) getCloudTviADNUM_URL {
     return [[@"http://" stringByAppendingString: BASE_IP] stringByAppendingString: @"/simple/info/adnum.json"];
}
@end
