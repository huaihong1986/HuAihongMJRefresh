//
//  OrientationNavigationController.h
//
//  Created by Shabbir Vijapura on 9/19/12.
//  Copyright (c) 2012 Depaul University. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OrientationNavigationController : UINavigationController

@end
