//
//  OCNChannelData.m
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import "OCNChannelData.h"

@implementation OCNChannelData

@synthesize channelID;
@synthesize upcode;
@synthesize num;
@synthesize name;
@synthesize updatedAt;
@synthesize logoURL;
@synthesize cloudtvsomeLogoUrl;

@synthesize categories;
@synthesize resourcesEndpoint,resources;
@synthesize programsEndpoint;

- (NSString *)getlogoURL{ return self.logoURL;}
- (NSString *)getname{ return self.name;}
- (NSString *)getprogramsEndpoint{ return self.programsEndpoint;}
- (NSString *)getresourcesEndpoint{ return self.resourcesEndpoint;}
- (NSString *)getupcode{ return self.upcode;}
- (NSString *)getupdatedAt{ return self.updatedAt;}
- (NSString *)getcloudtvsomeLogoUrl{ return self.cloudtvsomeLogoUrl;}
- (NSString *)getchannelID{ return self.channelID;}
- (NSString *)getnum{ return self.num;}
- (NSArray *)getcategories{ return self.categories;}
- (NSArray *)getresources{ return self.resources;}
@end
