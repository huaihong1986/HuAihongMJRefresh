//
//  VideoPlayerViewController.h
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import <MediaPlayer/MediaPlayer.h>
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"
#import "SBJson.h"
#import "ChannelDetailDelegate.h"
#import "VideoDataItem.h"
typedef void (^OnDisappearListener)(MPMoviePlayerViewController* ctrl);
typedef void (^OnSwitchBtnTapListener)(MPMoviePlayerViewController* ctrl);

@interface VideoPlayerViewController : MPMoviePlayerViewController<UIWebViewDelegate>
{
  
}

@property (weak) id<ChannelDetailDelegate> ChannelDetaildelegate;
@property (readwrite, copy) OnDisappearListener onDisappearListener;
@property (readwrite, copy) OnSwitchBtnTapListener onSwitchBtnTapListener;
@property (nonatomic) BOOL ended;
@property (nonatomic) BOOL shouldAllowSwitch;
@property (nonatomic) BOOL shouldAllowHideAfterPlay;
@property (nonatomic) UIButton *switchBtn;
@property (nonatomic) UIScrollView *tvseriesview;
@property (nonatomic) BOOL showingSwitchBtn;
@property (nonatomic) BOOL showingtvSeriesView;
@property (nonatomic) BOOL contvSeries;
@property (nonatomic) BOOL notYetDisappeared;
@property (nonatomic) NSString *tvseries_id;
@property (nonatomic) NSString *tvseries_Order;
@property (nonatomic) NSString *tvseries_playUrl;
@property ( nonatomic) NSMutableArray *tvseriesArray;
@property ( nonatomic) VideoDataItem *videoData;
- (void) setAllowSwitch:(BOOL)_shouldAllowSwitch;

@end
