//
//  AsyncImageView.m
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import "AsyncImageView.h"


// This class demonstrates how the URL loading system can be used to make a UIView subclass
// that can download and display an image asynchronously so that the app doesn't block or freeze
// while the image is downloading. It works fine in a UITableView or other cases where there
// are multiple images being downloaded and displayed all at the same time.

@implementation AsyncImageView

@synthesize data, connection, img;

- (void)loadImageFromURL:(NSURL *)url {
    
	NSURLRequest *request = [NSURLRequest requestWithURL:url ];
	self.connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    //notice how delegate set to self object
    self.data = [[NSMutableData alloc] init];
	
}

//To make sure whether the connection is nil
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    //NSLog(@"the header of the response ");
    
    NSHTTPURLResponse *res = (NSHTTPURLResponse*)response;
    StateNewPic = [res statusCode];
    
    //To make sure the state is correct
    if(StateNewPic != 200)
        return;
    
    //To make sure whether the state  is already open
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
}

//To make sure whether the data of the URL connection arrives
- (void)connection:(NSURLConnection *)theConnection didReceiveData:(NSData *)incrementalData
{
    //NSLog(@"ImgData   %@",incrementalData );
    
    if(StateNewPic != 200)
        return;
    
    [self.data appendData:incrementalData];
}

//To make sure whether all the data is alreadly downloaded
- (void)connectionDidFinishLoading:(NSURLConnection *)theConnection
{
	
    
    if(StateNewPic != 200)
        return;
    
    if(self.data) {
        self.img =[UIImage imageWithData:self.data];
        
        //To make sure the self data can transform a complete image
        if(self.img) {
            
           [self setImage:self.img];
        
        }
        
    }
    return;
}




@end
