//
//  MenuItem.h
//  CloudTvSimple
//
//  Created by Hu on 06/02/15.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuItem : UIView
{}
typedef void (^OnMenuItemTapListener)(UIView*);
@property ( nonatomic) IBOutlet UIImageView *imageleftView;
@property (weak, nonatomic) IBOutlet UIView *BgView;
@property ( nonatomic) IBOutlet UIImageView *imagerightView;
@property ( nonatomic) IBOutlet UILabel *MiddleName;

@property (nonatomic, strong) OnMenuItemTapListener onMenuItemTapListener;
@end
