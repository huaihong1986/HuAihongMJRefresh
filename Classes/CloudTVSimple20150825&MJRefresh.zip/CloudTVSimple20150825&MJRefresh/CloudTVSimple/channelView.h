//
//  channelView.h
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OCNChannelData.h"
#import "ChannelDetailDelegate.h"
#import "MarqueeLabel.h"

@interface channelView : UIView<UIAlertViewDelegate> {
    
    UIAlertView *alert;
    
}

typedef void (^OnChannelViewTapListener)(UIView*);


@property ( nonatomic) IBOutlet UIImageView *imageView;
@property ( nonatomic) IBOutlet UILabel *channelLabel;
@property ( nonatomic) IBOutlet UILabel *watchingLabel;
@property ( nonatomic) IBOutlet UILabel *willWatchLabel;

@property ( nonatomic) OCNChannelData *channelData;

@property ( nonatomic) MarqueeLabel *watchingMarqueeLabel;
@property ( nonatomic) MarqueeLabel *willWatchMarqueeLabel;

@property (weak, nonatomic) IBOutlet UIView *watchingLabelContainer;
@property (weak, nonatomic) IBOutlet UIView *willWatchLabelContainer;
@property (nonatomic, strong) OnChannelViewTapListener onChannelViewTapListener;

- (void)setWatchingText: (NSString *)str;
- (void)setWillWatchText: (NSString *)str;

@end
