//
//  Toucher.m
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import "Toucher.h"

@implementation Toucher

@synthesize movedHandler;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [[event allTouches] anyObject];
    CGPoint touchLocation = [touch locationInView:self];
    if (movedHandler){
        movedHandler(event, touchLocation);
    }
}

@end
