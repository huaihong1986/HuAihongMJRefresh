//
//  VideoPlayerViewController.m
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import "VideoPlayerViewController.h"
#import "TelePlayDataItem.h"
#import "Constant.h"
@implementation VideoPlayerViewController

@synthesize onDisappearListener;
@synthesize onSwitchBtnTapListener;
@synthesize ended;
@synthesize switchBtn, showingSwitchBtn, shouldAllowSwitch, shouldAllowHideAfterPlay,tvseriesview,showingtvSeriesView;
@synthesize notYetDisappeared;
@synthesize tvseries_id,tvseriesArray,tvseries_playUrl,tvseries_Order,contvSeries,videoData;
@synthesize ChannelDetaildelegate;


- (id)initWithNibName:(NSString *) nibNameOrNil bundle:(NSBundle *) nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    
    if (self)
    {
        self.notYetDisappeared = YES;
        self.ended = NO;
        self.shouldAllowSwitch = YES;
        self.shouldAllowHideAfterPlay = NO;
    }
    return self;
}

- (IBAction)onSwitchBtnTap:(id)sender
{
	
    if (self.shouldAllowSwitch)
    {
        if (self.onSwitchBtnTapListener)
        {
            self.onSwitchBtnTapListener(self);
            [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(hideSwitchBtn) object:nil];
            
           
        }
    }
}

- (void)viewWillDisappear:(BOOL)animated{
    self.notYetDisappeared = NO;
    if (onDisappearListener != nil){
        onDisappearListener(self);
    }

 
    [super viewWillDisappear:animated];
    
    
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    
#ifdef DEBUG
    NSLog(@"WebView error:   %@", error);
#endif
    
    
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    [[NSURLCache sharedURLCache] removeAllCachedResponses];
    
    NSMutableURLRequest *req = (NSMutableURLRequest *)request;
   
    if ([req respondsToSelector:@selector(setValue:forHTTPHeaderField:)]) {
        
        
        NSString* date;
        NSDateFormatter* formatter = [[NSDateFormatter alloc]init];
        NSString *userID=@"test";
        [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss.SSS"];      //毫秒
        date = [formatter stringFromDate:[NSDate date]];
        
        [req setValue:userID forHTTPHeaderField:@"X-user-id"];
       
        if(webView.tag==2) {[req setValue:date forHTTPHeaderField:@"X-Time"];//To make sure get the newest information
            
        }
        
    }
    NSString *requestString = [[[request URL] absoluteString] stringByReplacingPercentEscapesUsingEncoding: NSUTF8StringEncoding];
    
    
    
    
    //修改密碼 webview 返回
   
    if([requestString hasSuffix:@"/phone/home.html"]&&webView.tag==2){
        
        [webView.superview removeFromSuperview];
       
        return NO;
    }
    
    
    return YES;
}


- (void)webViewDidFinishLoad:(UIWebView *)webView{
    NSLog(@"finished loading...");
    
    
    if(webView.tag==2){
       
        for (id subview in webView.subviews)
            if ([[subview class] isSubclassOfClass: [UIScrollView class]])
                webView.scrollView.bounces = NO;
        [[NSUserDefaults standardUserDefaults] setInteger:0 forKey:@"WebKitCacheModelPreferenceKey"];
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"WebKitDiskImageCacheEnabled"];//自己添加的，原文没有提到。
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"WebKitOfflineWebApplicationCacheEnabled"];//自己添加的，原文没有提到。
        [[NSUserDefaults standardUserDefaults] synchronize];        //After iOS 5
        
        
        [[NSURLCache sharedURLCache] removeAllCachedResponses];
    }
    
}



- (void)webViewDidStartLoad:(UIWebView *)webView{
    
    NSLog(@"start loading...");
}


-(UIView*) getWebView:(UIWebView *)webView AndFrame:(CGRect)frame OnClose:(UITapGestureRecognizer *)listener{
    UIView* parent = [[UIView alloc] initWithFrame:frame];
    
    UIView* bg = [[UIView alloc] initWithFrame:frame];
    [bg setBackgroundColor:[UIColor colorWithRed:0.5 green:0.5 blue:0.5 alpha:0.5]];
    
    
    UIButton* closeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [closeBtn setImage:[UIImage imageNamed:@"closeBtn.png"] forState:UIControlStateNormal];
    closeBtn.frame = CGRectMake(frame.size.width - 29, 0, 29, 29);
    
    [closeBtn addGestureRecognizer:listener];
    
    [parent addSubview:bg];
    [parent addSubview:webView];
    [parent addSubview:closeBtn];
    
    return parent;
}



- (void)onCloseChangePasswordTap:(UITapGestureRecognizer *)recognizer {
    UIButton* btn = (UIButton*) recognizer.view;
    [btn.superview removeFromSuperview];
}

- (void) setAllowSwitch:(BOOL)_shouldAllowSwitch{
    self.shouldAllowSwitch = _shouldAllowSwitch;
    self.shouldAllowHideAfterPlay = _shouldAllowSwitch;
}

- (void)videoPlayerItemStateChanged:(NSNotification *)notification {
    if (self.moviePlayer.playbackState == MPMoviePlaybackStatePlaying){
        if (self.shouldAllowHideAfterPlay){
            [self performSelector:@selector(hideSwitchBtn) withObject:nil afterDelay:5];
            self.shouldAllowHideAfterPlay = NO;
        }
    }
}



- (void)moviePlayerPlaybackDidFinish:(NSNotification *)notification {
   
    
  
    

    NSError* error = [[notification userInfo] valueForKey: @"error"];
    [UIApplication sharedApplication].idleTimerDisabled=NO;
    if (error != nil){
       
        NSLog(@"error=%@", [error localizedDescription]);
        
        NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
        NSString * message=@"节目无法播放(E5105)";
        if([userDefault objectForKey:@"messages_message"]){
            NSDictionary * messageReportDic=[userDefault objectForKey:@"messages_message"];
            if([messageReportDic objectForKey:@"E5105"]){
                NSDictionary * messageDic=[messageReportDic objectForKey:@"E5105"];
                
                message=[messageDic objectForKey:@"message"];
            }
        }
        UIAlertView * alert= [[UIAlertView alloc] initWithTitle:@"提示"
                                                        message:message
                                                       delegate:self
                                              cancelButtonTitle:@"知道了"
                                              otherButtonTitles:nil];
        [alert show];

        return;
     
        
       
        
    }
    else {
       
        //If is TVseries then play the next one
       
        if(self.contvSeries&&[self.tvseries_id intValue]!=0&&(([self.tvseries_Order intValue]+1)<[self.tvseriesArray count]))
        {
            
            
            [self.tvseriesview removeFromSuperview];
            self.showingtvSeriesView=NO;
            
            
           
            
            self.tvseries_Order=[NSString stringWithFormat:@"%d",([self.tvseries_Order intValue]+1)];
            
            
            
            
            
            TelePlayDataItem* seriesData = (TelePlayDataItem*)[self.tvseriesArray objectAtIndex:([self.tvseries_Order intValue])];
            [self.ChannelDetaildelegate VideoPage:seriesData.gettvs_play :[NSString stringWithFormat:@"%@",self.tvseries_id]:self.tvseries_Order :self.videoData];
            
            
        }
      
       
    }
  
}


- (void)viewWillAppear:(BOOL)animated {
   
    [[UIApplication sharedApplication] setStatusBarOrientation:UIInterfaceOrientationLandscapeLeft animated:NO];
    UIViewController *mVC = [[UIViewController alloc] init];
    [self presentModalViewController:mVC animated:NO];
    [self dismissModalViewControllerAnimated:NO];
    
    [super viewWillAppear:animated];
  
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    self.contvSeries=NO;
    self.showingtvSeriesView=NO;
    
    self.switchBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.switchBtn.frame = CGRectMake(self.view.frame.size.height - 48, (self.view.frame.size.width-180)/2+180, 44, 25);
   
    [self.switchBtn setTitle:@"选集" forState:UIControlStateNormal];
    self.switchBtn.titleLabel.font = [UIFont systemFontOfSize:12];
    [self.switchBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.switchBtn addTarget:self action:@selector(onSwitchBtnTap:) forControlEvents:UIControlEventTouchUpInside];
    [self.switchBtn addTarget:self  action:@selector(clickswitchButton:) forControlEvents:UIControlEventTouchUpInside];
    self.switchBtn.hidden=YES;
    self.switchBtn.enabled = NO;
    [self.view addSubview:self.switchBtn];
    self.showingSwitchBtn = NO;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(videoPlayerItemStateChanged:) name:MPMoviePlayerPlaybackStateDidChangeNotification object:self.moviePlayer];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(moviePlayerPlaybackDidFinish:) name:MPMoviePlayerPlaybackDidFinishNotification object:self.moviePlayer];
   
    
    
    [UIApplication sharedApplication].idleTimerDisabled=YES;
    if([self.tvseries_id intValue]!=0) {
        self.showingSwitchBtn = YES;
        self.switchBtn.hidden=NO;
        self.switchBtn.enabled = YES;
        [self performSelector:@selector(hideSwitchBtn) withObject:nil afterDelay:6];
        self.contvSeries=YES;
        self.tvseriesArray=[[NSMutableArray alloc] init];
        self.tvseriesview =[[UIScrollView alloc] initWithFrame:CGRectMake(self.view.frame.size.height-180, (self.view.frame.size.width-180)/2, 180, 180)];
        [self.tvseriesview setAlpha:0.25];
        self.showingtvSeriesView=NO;
        self.tvseriesview.hidden=YES;
        self.tvseriesview.backgroundColor = [UIColor lightTextColor];
        [self.view addSubview:self.tvseriesview];
        NSString * seriesurl = [NSString stringWithFormat:@"%@",self.tvseries_id];
        [self loadAllTvSeriesNums:[[[Constant getTELEPLAY_SERIES_URL] stringByAppendingString: seriesurl] stringByAppendingString: @".json"]
        //Test case
        //[self loadAllTvSeriesNums:[@"http://211.144.83.147:9000/tvseries:" stringByAppendingString: seriesurl]
        WhenComplete:^(NSArray * tvList)
        {
            
                for (int i = 0, l = [tvList count]-1; i <= l; i++)
                {
                    NSDictionary* tvseries = [tvList objectAtIndex:i];
                    TelePlayDataItem* seriesData = [[TelePlayDataItem alloc] init];
                    seriesData.tvs_id=[NSString stringWithFormat:@"%@",[tvseries objectForKey:@"tvs_id"]];
                    seriesData.tvs_num=[NSString stringWithFormat:@"%@",[tvseries objectForKey:@"tvs_num"]];
                    seriesData.tvs_play=[NSString stringWithFormat:@"%@",[tvseries objectForKey:@"tvs_play"]];
                    [self.tvseriesArray addObject:seriesData];
                   
                    UIButton* catBtn = [UIButton buttonWithType:UIButtonTypeCustom];
                    catBtn.backgroundColor=[UIColor grayColor];
                   
                    [catBtn setBackgroundImage:nil forState:UIControlStateNormal];
                    [catBtn setBackgroundImage:[UIImage imageNamed:@"TvseriesSel.png"] forState:UIControlStateHighlighted];
                    catBtn.frame = CGRectMake((i%6)*30 ,(i/6)*30, 25, 25);
                    [catBtn setTitle:seriesData.gettvs_num forState:UIControlStateNormal];
                    catBtn.titleLabel.font = [UIFont systemFontOfSize:12];
                    [catBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                    catBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
                    [catBtn addTarget:self action:@selector(onTapTvseries:) forControlEvents:UIControlEventTouchUpInside];
                    catBtn.tag=i;
                  
                    if([self.tvseries_playUrl isEqualToString:seriesData.gettvs_play ]&&([self.tvseries_Order intValue]==i))
                    {
                        catBtn.backgroundColor=[UIColor redColor];
                    }
                    [self.tvseriesview addSubview:catBtn];
                }
            
                [self.tvseriesview setContentSize:CGSizeMake(180, 180)];
                if(([tvList count]/6)>=6)  [self.tvseriesview setContentSize:CGSizeMake(180, ([tvList count]-1)/6*30+30)];
            
            }
        OrFail:^(NSError * err)
        {
                                   
        }];
            
            
            
            
        

    
    
    
    }
    
}
-(void)loadAllTvSeriesNums: (NSString*) resourceURL  WhenComplete:(void (^)(NSArray*)) completeBlk OrFail: (void (^)(NSError*)) failBlk{
   
    
    NSURL* url = [NSURL URLWithString:[resourceURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
    ASIHTTPRequest* _req = [ASIHTTPRequest requestWithURL:url];
    
    
    
    
    __weak ASIHTTPRequest* req = _req;
    
    
    [req setCompletionBlock:^{
       
        
        SBJsonParser* parser = [[SBJsonParser alloc] init];
        NSData*jsondata = [req responseData];
        NSString*jsonString = [[NSString alloc]initWithBytes:[jsondata bytes]length:[jsondata length]encoding:NSUTF8StringEncoding];
        //Test case
        //@"[{\"tvs_id\":3,\"tvs_num\":1,\"tvs_play\":\"http://211.144.83.147/cloudtv/video/83/83.m3u8\"},{\"tvs_id\":3,\"tvs_num\":2,\"tvs_play\":\"http://211.144.83.147/cloudtv/video/83/83.m3u8\"}]";//
        NSArray* localNowtvseriesnums = [parser objectWithString:jsonString ];
        
       
        completeBlk(localNowtvseriesnums);
    }];
    [req setFailedBlock:^{
        NSError* error = [req error];
        failBlk(error);
    }];
    [req startAsynchronous];
    
    
}

- (void)clickswitchButton:(id)sender
{
  
    if(!self.showingtvSeriesView){
        self.tvseriesview.hidden=NO;
        self.showingtvSeriesView=YES;
        [self performSelector:@selector(hidetvseriesView) withObject:nil afterDelay:6];
        
    }
    else {
    
        self.tvseriesview.hidden=YES;
        self.showingtvSeriesView=NO;
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(hidetvseriesView) object:nil];
    }
    

}
- (IBAction)onTapTvseries:(id) sender{
    NSArray* cats = [self.tvseriesview subviews];
    for (int i = 0, l = [cats count]; i < l; i++){
        UIView* cat = [cats objectAtIndex:i];
        if ([cat class] == [UIButton class]){
            UIButton* catBtn = (UIButton*) cat;
            [catBtn setBackgroundImage:nil forState:UIControlStateNormal];
			catBtn.backgroundColor=[UIColor grayColor];
        }
    }
    [self.tvseriesview removeFromSuperview];
   
  
    UIButton* btn = (UIButton*) sender;
    btn.backgroundColor=[UIColor redColor];
    self.contvSeries=NO;
    TelePlayDataItem* seriesData = (TelePlayDataItem*)[self.tvseriesArray objectAtIndex:btn.tag];

   

    self.tvseries_Order=[NSString stringWithFormat:@"%lu",btn.tag];
    
  
   [self.ChannelDetaildelegate VideoPage:seriesData.gettvs_play :[NSString stringWithFormat:@"%@",self.tvseries_id]:self.tvseries_Order :self.videoData];

}

    
   
    


- (void)showSwitchBtn{
    self.showingSwitchBtn = YES;
  
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDelay:0.2];
    [UIView setAnimationDuration:0.35];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
    self.switchBtn.alpha = 1;
    
    
    [UIView commitAnimations];
}

- (void)hideSwitchBtn{
    self.showingSwitchBtn = NO;

    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDelay:0.25];
    [UIView setAnimationDuration:0.35];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
    
    self.switchBtn.alpha = 0;
   
    [UIView commitAnimations];
}
- (void)hidetvseriesView{
   if(self.showingtvSeriesView){
       self.tvseriesview.hidden=YES;
       self.showingtvSeriesView=NO;
   }
   
}
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    
    
    if (self.shouldAllowSwitch){
        if (self.showingSwitchBtn)
        {
            [self hideSwitchBtn];
            
            [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(hideSwitchBtn) object:nil];
        }
        else
        {
            [self showSwitchBtn];
            
			if (self.moviePlayer.playbackState == MPMoviePlaybackStatePlaying){
				[self performSelector:@selector(hideSwitchBtn) withObject:nil afterDelay:5];
			}
        }
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
     [UIApplication sharedApplication].idleTimerDisabled = NO;
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft || interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskLandscape;
}





@end
