//
//  MenuView.h
//  OCNOCN
//
//  Created by Yan on 21/6/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MenuDelegate.h"
@interface MenuView : UIView<UITextFieldDelegate>{
   
}

@property ( nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UIButton *IPSaveBtn;
@property ( nonatomic) IBOutlet UITextField* IPField;
@property (weak) id<MenuDelegate> delegate;

-(IBAction)saveIPAction:(id)sender;
-(void)loadMenuItem;
-(void)updateIpEdittext;

@end
