//
//  TelePlayDataItem.m
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import "TelePlayDataItem.h"

@implementation TelePlayDataItem

@synthesize tvs_id,tvs_num,tvs_play;

- (NSString *)gettvs_id{
    return self.tvs_id;
}
- (NSString *)gettvs_num{
    return self.tvs_num;
}
- (NSString *)gettvs_play{
    return self.tvs_play;
}

@end
