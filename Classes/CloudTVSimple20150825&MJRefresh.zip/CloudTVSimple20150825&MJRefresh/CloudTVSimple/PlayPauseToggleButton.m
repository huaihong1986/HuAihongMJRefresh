//
//  PlayPauseToggleButton.m
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import "PlayPauseToggleButton.h"

//used in 直播 originally, may need to remove it
@implementation PlayPauseToggleButton

@synthesize btn;

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.btn = [UIButton buttonWithType:UIButtonTypeCustom];
        self.btn.frame = CGRectMake(0, 0, frame.size.width, frame.size.height);
        [self addSubview:self.btn];
        [self setShowPlaying:NO];
    }
    return self;
}

- (void)addTarget:(id) target action:(SEL) selector forControlEvents:(UIControlEvents) events{
    [self.btn addTarget:target action:selector forControlEvents:events];
}
         
- (void)setShowPlaying:(BOOL)showPlaying {
    _isPlaying = showPlaying;
    NSLog(@"Setting isPlaying");
    
    if (showPlaying) {
        [self.btn setBackgroundImage:[UIImage imageNamed:@"03play btn.png"] forState:UIControlStateNormal];
    }else{
        [self.btn setBackgroundImage:[UIImage imageNamed:@"03stop btn.png"] forState:UIControlStateNormal];
    }
}

- (BOOL)showPlaying {
    return _isPlaying;
}

@end
