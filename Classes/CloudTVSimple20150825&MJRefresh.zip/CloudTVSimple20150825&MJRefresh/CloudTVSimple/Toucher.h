//
//  Toucher.h
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^Handler)(UIEvent*, CGPoint);

@interface Toucher : UIView

@property (readwrite, copy) Handler movedHandler;

@end
