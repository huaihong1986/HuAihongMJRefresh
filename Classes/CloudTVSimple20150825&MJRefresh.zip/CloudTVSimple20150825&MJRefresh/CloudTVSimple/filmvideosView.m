//
//  filmvideosView.m
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import "filmvideosView.h"


@implementation filmvideosView

@synthesize titleLabel=_titleLabel;

@synthesize onFilmVideosViewTapListener;


@synthesize videoData;

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
	if (self.onFilmVideosViewTapListener) {
		self.onFilmVideosViewTapListener(self);
	}
}






@end
