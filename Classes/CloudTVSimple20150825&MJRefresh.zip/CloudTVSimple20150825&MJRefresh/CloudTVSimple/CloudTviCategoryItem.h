//
//  CloudTviCategoryItem.h
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CloudTviCategoryItem : NSObject
@property (nonatomic) NSString *col_id;
@property (nonatomic) NSString *col_name;
@property (nonatomic) NSString *col_action;
@property (nonatomic) NSString *col_resource;

- (NSString *)getCol_name;
- (NSString *)getCol_action;
- (NSString *)getCol_resource;
- (NSString *)getCol_id;
@end
