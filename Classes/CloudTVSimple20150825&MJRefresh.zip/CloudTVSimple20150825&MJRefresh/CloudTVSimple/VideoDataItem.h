//
//  VideoDataItem.h
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VideoDataItem : NSObject
@property (nonatomic) NSString *cid;
@property (nonatomic) NSString *cont_column;
@property (nonatomic) NSString *cont_program;
@property (nonatomic) NSString *cont_tvseries_id;
@property (nonatomic) NSString *description;
@property (nonatomic) NSString *picUrl;
@property (nonatomic) NSString *playUrl;


- (NSString *)getcid;
- (NSString *)getcont_column;
- (NSString *)getcont_program;
- (NSString *)getcont_tvseries_id;
- (NSString *)getdescription;
- (NSString *)getpicUrl;
- (NSString *)getplayUrl;

@end
