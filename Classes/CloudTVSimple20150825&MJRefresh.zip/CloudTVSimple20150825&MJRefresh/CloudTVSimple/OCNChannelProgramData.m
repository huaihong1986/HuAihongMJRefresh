//
//  OCNChannelProgramData.m
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import "OCNChannelProgramData.h"

@implementation OCNChannelProgramData

@synthesize channelID;
@synthesize name;
@synthesize pastProgramData;
@synthesize nowProgramData;
@synthesize futureProgramData;

- (NSString *)getChannelID{
    return self.channelID;
}

@end
