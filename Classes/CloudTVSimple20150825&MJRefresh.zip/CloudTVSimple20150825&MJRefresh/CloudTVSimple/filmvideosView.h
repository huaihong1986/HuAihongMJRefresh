//
//  filmvideosView.h
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CloudTviCategoryItem.h"
#import "MarqueeLabel.h"
#import "VideoDataItem.h"
@interface filmvideosView : UIView {
   }
typedef void (^OnFilmVideosViewTapListener)(UIView*);



@property (nonatomic) IBOutlet UILabel * titleLabel;


@property (nonatomic, strong) OnFilmVideosViewTapListener onFilmVideosViewTapListener;
@property (nonatomic) VideoDataItem * videoData;









@end
