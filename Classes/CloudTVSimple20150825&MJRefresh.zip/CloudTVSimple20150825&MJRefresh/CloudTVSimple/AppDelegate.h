//
//  AppDelegate.h
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-25.
//  Copyright (c) 2014年 ___FULLUSERNAME___. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainViewController.h"
#import "OrientationNavigationController.h"
@interface AppDelegate :UIResponder <UIApplicationDelegate>


@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, assign) float originalVolume;
@property (strong, nonatomic) MainViewController *viewController;
@property (strong, nonatomic) UINavigationController *navcontroller;
+ (void) setSystemVolume: (float) volume;
+ (void) setAppVolume: (float) volume;
+ (float) getSystemVolume;
@end
