//
//  Constant.h
//  CloudTvSimple
//
//  Created by Hu on 06/02/15.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Constant : NSObject
+ (void)setBaseIP:(NSString *)IP;
+ (NSString *) getOnlyBaseIP;
+ (NSString *) getBaseIP;
+ (NSString *) getCloudTviCategory_URL;
+ (NSString *) getTELEPLAY_SERIES_URL;
+ (NSString *) getCloudTviADNUM_URL;
@end
