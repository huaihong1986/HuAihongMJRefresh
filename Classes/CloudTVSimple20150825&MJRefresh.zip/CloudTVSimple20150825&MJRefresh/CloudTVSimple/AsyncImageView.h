//
//  AsyncImageView.h
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "filmvideosView.h"

@interface AsyncImageView : UIImageView {
    
    int StateNewPic;
	
}

@property (nonatomic) NSMutableData *data;
@property (nonatomic) NSURLConnection *connection;

@property (nonatomic) UIImage *img;

- (void)loadImageFromURL:(NSURL *)url;

@end
