//
//  ChannelDetailDelegate.h
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VideoDataItem.h"
@class SecondPageViewController;


@protocol ChannelDetailDelegate <NSObject>
- (void)SecondPage:(SecondPageViewController*)secondPageViewController;
- (void)VideoPage:(NSString *) Playurl : (NSString *) tvseries_id : (NSString *) tvseries_Order : (VideoDataItem*)videodata;

@end