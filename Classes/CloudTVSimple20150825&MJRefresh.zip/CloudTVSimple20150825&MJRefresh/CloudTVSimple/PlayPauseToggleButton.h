//
//  PlayPauseToggleButton.h
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlayPauseToggleButton : UIView{
    BOOL _isPlaying;
}

@property ( nonatomic) UIButton *btn;

- (void)setShowPlaying: (BOOL) showPlaying;
- (BOOL)showPlaying;
- (void)addTarget:(id) target action:(SEL) selector forControlEvents:(UIControlEvents) events;
//@property (retain, nonatomic) IBOutlet UILabel *timeLabel;

@end
