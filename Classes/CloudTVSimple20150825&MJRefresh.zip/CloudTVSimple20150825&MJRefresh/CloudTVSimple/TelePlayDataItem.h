//
//  TelePlayDataItem.h
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TelePlayDataItem : NSObject
@property (nonatomic) NSString *tvs_id;
@property (nonatomic) NSString *tvs_num;
@property (nonatomic) NSString *tvs_play;









- (NSString *)gettvs_id;
- (NSString *)gettvs_num;
- (NSString *)gettvs_play;

@end
