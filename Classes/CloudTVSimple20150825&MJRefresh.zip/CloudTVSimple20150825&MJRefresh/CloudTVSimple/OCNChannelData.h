//
//  OCNChannelData.h
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OCNChannelData : NSObject
@property (nonatomic) NSArray *categories;
@property (nonatomic) NSString *channelID;
@property (nonatomic) NSString *logoURL;
@property (nonatomic) NSString *name;
@property (nonatomic) NSString *num;
@property (nonatomic) NSString *programsEndpoint;
@property (nonatomic) NSString *resourcesEndpoint;
@property (nonatomic) NSString *upcode;
@property (nonatomic) NSArray *resources;

@property (nonatomic) NSString *updatedAt;

@property (nonatomic) NSString *cloudtvsomeLogoUrl;



- (NSString *)getlogoURL;
- (NSString *)getname;
- (NSString *)getprogramsEndpoint;
- (NSString *)getresourcesEndpoint;
- (NSString *)getupcode;
- (NSString *)getupdatedAt;
- (NSString *)getcloudtvsomeLogoUrl;
- (NSString *)getchannelID;
- (NSNumber *)getnum;
- (NSArray *)getcategories;
- (NSArray *)getresources;
@end
