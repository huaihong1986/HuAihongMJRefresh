//
//  MainViewController.h
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-25.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"
#import "SBJson.h"
#import "CloudTviCategoryItem.h"
#import "filmvideosView.h"
#import "AsyncImageView.h"
#import "VideoPlayerViewController.h"
#import "OCNChannelData.h"
#import "channelView.h"
#import "OCNChannelProgramData.h"
#import "OCNProgramData.h"
#import "SecondPageViewController.h"
#import "ChannelDetailDelegate.h"
#import "MenuDelegate.h"
#import "MenuView.h"
@interface MainViewController : ATViewController<MenuDelegate,ChannelDetailDelegate,UIWebViewDelegate, UIAlertViewDelegate,UIScrollViewDelegate>
{

UIAlertView * alert;
int   MinPlayTime;
int   categoryid;
BOOL  allowNext;
BOOL  isMenushowing;
int   rowWidth ;
int   rowHeight ;
}
@property (nonatomic) IBOutlet UIView *MainView;
@property (nonatomic) MenuView *currentMenuView;
@property (nonatomic) SecondPageViewController *currentSecondPageViewController;
@property (nonatomic) IBOutlet UIScrollView *categories;
@property (nonatomic) NSMutableArray * categoryArray;
@property (nonatomic) IBOutlet UIScrollView *scrollView;
@property (nonatomic) VideoPlayerViewController *videoPlayer;
@property (nonatomic) NSTimer *nowPlayingTimer;
@property (nonatomic) NSString *LiveHostName;
@property (weak,nonatomic) IBOutlet UIButton *removeMenuBtn;

- (void) attachEventToSecondPageVC: (SecondPageViewController *) vc;
- (void) showAlert:(NSString *) title : (NSString *) msg;
@end
