//
//  MainViewController.m
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-25.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import "MainViewController.h"
#import "MBProgressHUD.h"
#import "PAImageView.h"
#import "Constant.h"
#import "MJRefresh.h"
static const CGFloat MJDuration = 2.0;
@interface MainViewController ()

@end

@implementation MainViewController

@synthesize categories,categoryArray,scrollView,videoPlayer,nowPlayingTimer,currentSecondPageViewController,LiveHostName,currentMenuView,removeMenuBtn,MainView;

static int filmchannelIconTag = 1;
static int filmchannelNameTag = 2;
static int xOffset = 6;
static int rowWidthMenu = 228;
static int scrollViewPadding = 15;
static  NSString * chanelID;
static  NSString *  NOWPLAY_URLLast = @"/api/v2/live/programs/now_playing.json";

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


-(void)SecondPage:(SecondPageViewController *)secondPageViewController {
   
	if (self.currentSecondPageViewController && self.currentSecondPageViewController.isAppearing) {
		
		[self.navigationController popViewControllerAnimated:NO];
	}
    self.currentSecondPageViewController = secondPageViewController;
    [self.navigationController pushViewController:secondPageViewController animated:YES];
    
}



- (void)VideoPage:(NSString *) Playurl : (NSString *) tvseries_id : (NSString *) tvseries_Order :(VideoDataItem *)videodata
{
    
  
    if(Playurl!=nil){
        allowNext=NO;
        self.videoPlayer = [[VideoPlayerViewController alloc] initWithContentURL:[NSURL URLWithString: [Playurl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
        self.videoPlayer.tvseries_id=tvseries_id;
        self.videoPlayer.tvseries_playUrl=Playurl;
        self.videoPlayer.tvseries_Order=tvseries_Order;
        self.videoPlayer.videoData=videodata;
        self.videoPlayer.ChannelDetaildelegate=self;
        __weak MainViewController * weakSelf= self;
        self.videoPlayer.onDisappearListener = ^(MPMoviePlayerViewController* ctrl){
            [weakSelf dispatchBreakEvent];
        };
        
        [self.videoPlayer.moviePlayer prepareToPlay];
        [self.videoPlayer.moviePlayer setUseApplicationAudioSession:NO];
        [self.videoPlayer.moviePlayer setShouldAutoplay:YES];
        [self.videoPlayer.moviePlayer setControlStyle:2];
        
        [self presentViewController:self.videoPlayer animated:NO completion:nil];

        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(videoPlayerItemDone:) name:MPMoviePlayerDidExitFullscreenNotification object:self.videoPlayer];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(videoPlayerItemStateChanged:) name:MPMoviePlayerPlaybackStateDidChangeNotification object:self.videoPlayer.moviePlayer];
	
    }
    else{
        
        ;//[self showAlert:@"提示" :@"节目播放URL为nil"];
    }
    
}
- (void)ReloadMainView{
    
 
    if(isMenushowing){
    
        [UIView animateWithDuration:0.2f
                              delay:0.0f
                            options:UIViewAnimationOptionCurveEaseOut
                         animations:^
         {
             
             CGRect frame = currentMenuView.frame;
             frame.origin.x = frame.origin.x - frame.size.width;
             currentMenuView.frame = frame;
         }completion:nil];
        isMenushowing=FALSE;
        [self.removeMenuBtn removeFromSuperview];
        [self.MainView setFrame:CGRectMake(0, 0, self.MainView.frame.size.width, self.MainView.frame.size.height)];
        
    }
   [self loadAllCategories];

}

- (void)attachEventToSecondPageVC: (SecondPageViewController*)vc {
    
   
    __weak SecondPageViewController * _vc=vc;
  
    vc.onFinishPushBtnTapListener= ^(){
        [_vc.player play];
      
        
    };
    
}



-(void) loadAllAdNums: (NSString *) resourceURL  WhenComplete:(void (^)(NSArray*)) completeBlk OrFail: (void (^)(NSError*)) failBlk {
   
    
    NSURL* url = [NSURL URLWithString:[resourceURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    ASIHTTPRequest* _req = [ASIHTTPRequest requestWithURL:url];
    __weak ASIHTTPRequest* req = _req;
    [req setCompletionBlock:^{
        SBJsonParser* parser = [[SBJsonParser alloc] init];
        NSData*jsondata = [req responseData];
        NSString*jsonString = [[NSString alloc]initWithBytes:[jsondata bytes]length:[jsondata length]encoding:NSUTF8StringEncoding];
        NSArray* localNowadnums = [parser objectWithString:jsonString ];
       
        completeBlk(localNowadnums);
    }];
    [req setFailedBlock:^{
        NSError* error = [req error];
        failBlk(error);
    }];
    [req startAsynchronous];
}

-(void)loadAllCategories {
    
    
    if(self.scrollView != nil) {
        NSArray *subviews =[self.scrollView subviews];
        for (int i = 0, l = [subviews count]; i < l; i++) {
            UIView* channelUIView = [subviews objectAtIndex:i];
            [channelUIView removeFromSuperview];
        }
    }
    if(self.categories != nil) {
        NSArray *subviews =[self.categories subviews];
        for (int i = 0, l = [subviews count]; i < l; i++) {
            UIView* channelUIView = [subviews objectAtIndex:i];
            [channelUIView removeFromSuperview];
        }
    }
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [self loadAllAdNums:[Constant getCloudTviADNUM_URL] WhenComplete:^(NSArray * adList) {
            ASIHTTPRequest * _req= [ASIHTTPRequest requestWithURL:[NSURL URLWithString:[[Constant getCloudTviCategory_URL] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
        
            __weak ASIHTTPRequest* req = _req;
            self.categoryArray=[[NSMutableArray alloc] init];
            [req setCompletionBlock:^{
         
            SBJsonParser* parser = [[SBJsonParser alloc] init];
            
            NSData*jsondata = [req responseData];
            NSString*jsonString = [[NSString alloc]initWithBytes:[jsondata bytes]length:[jsondata length]encoding:NSUTF8StringEncoding];
           
            
            if (jsonString != nil) {
                
                NSArray* data = [parser objectWithString:jsonString];

                if(data){
            
                            for (int i = 0, l = [data count] - 1; i <= l; i++){
                        
                                NSDictionary* channel = [data objectAtIndex:i];
                                CloudTviCategoryItem* categoryData = [[CloudTviCategoryItem alloc] init];
                               
                                categoryData.col_name=[channel objectForKey:@"col_name"];
                                
                                categoryData.col_resource=[channel objectForKey:@"col_resource"];
                                categoryData.col_id=[channel objectForKey:@"col_id"];
                                categoryData.col_action=[channel objectForKey:@"col_action"];
                                [self.categoryArray addObject:categoryData];
                                
                                NSString* category = categoryData.col_name ;
                                UIButton* catBtn = [UIButton buttonWithType:UIButtonTypeCustom];
                                catBtn.frame = CGRectMake(xOffset + i * 60, 0, 40, 40);
                                [catBtn setTitle:category forState:UIControlStateNormal];
                                catBtn.titleLabel.font = [UIFont systemFontOfSize:16];
                                [catBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
                                catBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
                                [catBtn addTarget:self action:@selector(onTapCategory:) forControlEvents:UIControlEventTouchUpInside];
                                
                                catBtn.tag=i;
                                [self.categories addSubview:catBtn];
                                /*if([adList count]>0){
                                    NSLog(@"Test Adlist%d",[adList count]);
                                    for(int j = 0, l = [adList count] - 1; j <= l; j++)
                                    {
                                        
                                        NSDictionary* ad = [adList objectAtIndex:j];
                                        NSString *nowcolid= [ad objectForKey:@"column_id"];
                                        NSString* nowadname=[ad objectForKey:@"adnum"];
                                        
                                        if([categoryData.getCol_id isEqual: nowcolid]&&nowadname&&[nowadname intValue]>0){
                                            
                                            UILabel *labellocal = [[UILabel alloc] initWithFrame:CGRectMake(xOffset+29 + i * 60, 0, 12, 15)];
                                            
                                            
                                            labellocal.text=[NSString stringWithFormat:@"%@",nowadname] ;
                                            labellocal.font = [UIFont systemFontOfSize:12];
                                            labellocal.backgroundColor = [UIColor clearColor];
                                    
                                            PAImageView *avaterImageView = [[PAImageView alloc]initWithFrame:CGRectMake(xOffset+25 + i * 60,-1, 13, 18) backgroundProgressColor:[UIColor clearColor] progressColor:[UIColor clearColor]];
                                            UIImage *oldImage =[UIImage imageNamed:@"Show.png"];
                                            UIImage *newImage=[self imageByApplyingAlpha:0.75 image:oldImage];
                                            [avaterImageView updateWithImage:newImage animated:NO];
                                            //[self.categories addSubview:avaterImageView];
                                            //[self.categories addSubview:labellocal];
                                            
                                            break;
                                            
                                        }
                                        
                                    }
                                    
                                    
                            
                            }*/
                            if (i == 0)
                            {
                                [self onTapCategory:catBtn];
                                
                                
                            }
                            
                        
                    }
                    //modefied by sm 20150318 start
                    //[self.categories setContentSize:CGSizeMake(xOffset + [self.categoryArray count] * 60, 40)];
                    [self.categories setContentSize:CGSizeMake(xOffset + [self.categoryArray count] * 60, 0)];
                    //modefied by sm 20150318 end
                    
                } else  [self showAlert:@"提示" :@"此IP对应的后台服务器数据返回不正确"];
                
                
            }
            
            
            [MBProgressHUD hideHUDForView:self.view animated:YES];
            
        }];
        [req setFailedBlock:^{
            NSError* error = [req error];
            
             [MBProgressHUD hideHUDForView:self.view animated:YES];
        }];
        [req startAsynchronous];
        
        
    }
 
    OrFail:^(NSError * err){
        
         [self showAlert:@"提示" :@"此IP对应的后台服务器数据返回不正确"];
         [MBProgressHUD hideHUDForView:self.view animated:YES];
        
    }];

}


- (UIImage *)imageByApplyingAlpha:(CGFloat)alpha  image:(UIImage*)image{
    
    UIGraphicsBeginImageContextWithOptions(image.size, NO, 0.0f);
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGRect area = CGRectMake(0, 0, image.size.width, image.size.height);
    CGContextScaleCTM(ctx, 1, -1);
    CGContextTranslateCTM(ctx, 0, -area.size.height);
    CGContextSetBlendMode(ctx, kCGBlendModeMultiply);
    CGContextSetAlpha(ctx, alpha);
    CGContextDrawImage(ctx, area, image.CGImage);
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return newImage;
    
}

- (IBAction)onTapCategory:(id) sender{
    NSArray* cats = [self.categories subviews];
    for (int i = 0, l = [cats count]; i < l; i++){
        
        UIView* cat = [cats objectAtIndex:i];
        if ([cat class] == [UIButton class]) {
            
            UIButton* catBtn = (UIButton*) cat;
            [catBtn setBackgroundImage:nil forState:UIControlStateNormal];
			[catBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
            
        }
    }
    
    UIButton* btn = (UIButton*) sender;
    [btn setBackgroundImage:[UIImage imageNamed:@"mainbtn-selected-bg-new.png"] forState:UIControlStateNormal];
	[btn setTitleEdgeInsets:UIEdgeInsetsMake(-2, 0, 0, 0)];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    categoryid=btn.tag;
    [self.categories scrollRectToVisible:btn.frame animated:YES];
    [self filterCategories];
}

- (void)slideCategory {
    NSArray* cats = [self.categories subviews];
    for (int i = 0, l = [cats count]; i < l; i++) {
        UIView* cat = [cats objectAtIndex:i];
        if ([cat class] == [UIButton class]){
            UIButton* catBtn = (UIButton*) cat;
            [catBtn setBackgroundImage:nil forState:UIControlStateNormal];
			[catBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
            if(catBtn.tag==categoryid){
                [catBtn setBackgroundImage:[UIImage imageNamed:@"mainbtn-selected-bg-new.png"] forState:UIControlStateNormal];
                [catBtn setTitleEdgeInsets:UIEdgeInsetsMake(-2, 0, 0, 0)];
                [catBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                [self.categories scrollRectToVisible:catBtn.frame animated:YES];
            }
        }
    }
  
    [self filterCategories];

}

- (void)addfilmvideos:(VideoDataItem*) videoitem {
   
    
    
    int index = [[self.scrollView subviews] count];
    
    NSArray *nibContents = [[NSBundle mainBundle] loadNibNamed:@"filmvideosView"
                                                         owner:self
                                                       options:nil];
    
    __weak filmvideosView *myView = [nibContents objectAtIndex:0];
    myView.videoData = videoitem;
	
    //Async download a image
    AsyncImageView* icon = (AsyncImageView*) [myView viewWithTag:filmchannelIconTag];
   
    NSURL* url = [NSURL URLWithString:[videoitem.picUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] ];
    
    [icon loadImageFromURL:url];
 
    
    
    UILabel* channelName = (UILabel*) [myView viewWithTag:filmchannelNameTag];
    if(videoitem.description) channelName.text =[@"   " stringByAppendingString:videoitem.description];
    //To make sure there is some description for the video
    
    myView.frame = CGRectMake(12, rowHeight * index+2, rowWidth, rowHeight);
    
    __weak MainViewController *weakSelf= self;
    myView.onFilmVideosViewTapListener = ^(UIView* view){
        
    
		[weakSelf onVideoTap:view];
	};
  
    [self.scrollView addSubview:myView];
   
    [self checkScrollViewHeight];
}


- (void)checkScrollViewHeight {
    if(self.scrollView != nil) {
		NSArray* channelSubviews = [self.scrollView subviews];
		CGFloat totalHeight = 0;
		for (int i = [channelSubviews count] - 1; i >= 0; i--){
			UIView* view = [channelSubviews objectAtIndex:i];
			if (! view.hidden){
                
				totalHeight += view.frame.size.height;
			}
		}
		
		if (totalHeight < self.scrollView.frame.size.height){
			totalHeight = self.scrollView.frame.size.height;
		}
		
        [self.scrollView setContentSize:CGSizeMake(rowWidth, totalHeight + scrollViewPadding)];
    }
}


- (void)checkLiveScrollViewHeight {
    if(self.scrollView != nil) {
		NSArray* channelSubviews = [self.scrollView subviews];
		CGFloat totalHeight = 0;
		for (int i = [channelSubviews count] - 1; i >= 0; i--) {
			UIView* view = [channelSubviews objectAtIndex:i];
			if (! view.hidden) {
                
				totalHeight += view.frame.size.height;
			}
		}
		
		if (totalHeight < self.scrollView.frame.size.height){
			totalHeight = self.scrollView.frame.size.height;
		}
		
        [self.scrollView setContentSize:CGSizeMake(rowWidth, totalHeight + 1)];
    }
}
- (void)videoPlayerItemStateChanged:(NSNotification *)notification {
    if (self.videoPlayer.moviePlayer.playbackState == MPMoviePlaybackStatePaused &&
        self.videoPlayer.moviePlayer.duration <= self.videoPlayer.moviePlayer.currentPlaybackTime + 5){
        
        self.videoPlayer.ended = YES;
        
    }
	   
    
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
    
#ifdef DEBUG
    NSLog(@"WebView error:   %@", error);
#endif
    
    
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    [[NSURLCache sharedURLCache] removeAllCachedResponses];
  
    NSMutableURLRequest *req = (NSMutableURLRequest *)request;
   
    if ([req respondsToSelector:@selector(setValue:forHTTPHeaderField:)]) {
      
        
        NSString* date;
        NSDateFormatter* formatter = [[NSDateFormatter alloc]init];
        NSString *userID=@"test";
        [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss.SSS"];      //毫秒
        date = [formatter stringFromDate:[NSDate date]];
       
        [req setValue:userID forHTTPHeaderField:@"X-user-id"];
       
        if(webView.tag==2)
        {
            [req setValue:date forHTTPHeaderField:@"X-Time"];
            
        }
        
    }
    NSString *requestString = [[[request URL] absoluteString] stringByReplacingPercentEscapesUsingEncoding: NSUTF8StringEncoding];
    
   
        
       
            //修改密碼 webview 返回
    
    if([requestString hasSuffix:@"/phone/home.html"]&&webView.tag==2) {
                
        [webView.superview removeFromSuperview];
       
        return NO;
    }
            
    
    return YES;
}


- (void)webViewDidFinishLoad:(UIWebView *)webView {
   
 
    //Avoid MemoryWarning
    if(webView.tag==2){
        
        
        for (id subview in webView.subviews)
            if ([[subview class] isSubclassOfClass: [UIScrollView class]])
                webView.scrollView.bounces = NO;
        [[NSUserDefaults standardUserDefaults] setInteger:0 forKey:@"WebKitCacheModelPreferenceKey"];
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"WebKitDiskImageCacheEnabled"];
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"WebKitOfflineWebApplicationCacheEnabled"];
        [[NSUserDefaults standardUserDefaults] synchronize];        //After iOS 5
        [[NSURLCache sharedURLCache] removeAllCachedResponses];
    
    }
 
}



- (void)webViewDidStartLoad:(UIWebView *)webView {
    
    NSLog(@"start loading...");
}

- (UIView*)getWebView:(UIWebView *)webView AndFrame:(CGRect)frame OnClose:(UITapGestureRecognizer *)listener{
    UIView* parent = [[UIView alloc] initWithFrame:frame];
    
    UIView* bg = [[UIView alloc] initWithFrame:frame];
    [bg setBackgroundColor:[UIColor colorWithRed:0.5 green:0.5 blue:0.5 alpha:0.5]];
    
    
    UIButton* closeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [closeBtn setImage:[UIImage imageNamed:@"closeBtn.png"] forState:UIControlStateNormal];
    closeBtn.frame = CGRectMake(frame.size.width - 29, 0, 29, 29);
    
    [closeBtn addGestureRecognizer:listener];
    
    [parent addSubview:bg];
    [parent addSubview:webView];
    [parent addSubview:closeBtn];
    
    return parent;
}

/*
 New Add
 to test the user whether have access permission vod video
 */
-(void)HavePerToAccVod: (VideoDataItem*)videodata WhenComplete:(void (^)(NSString*)) completeBlk OrFail: (void (^)(NSError*)) failBlk{
    
    NSString* url =[[[[[Constant getBaseIP] stringByAppendingString:@"/void/info/appCanDisplayByAsset.action?assetId="]stringByAppendingString:videodata.getcid] stringByAppendingString: @"&cont_program_id="] stringByAppendingString:videodata.getcont_program];//
    
    ASIHTTPRequest * _req= [ASIHTTPRequest requestWithURL:[NSURL URLWithString:[url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
    
    __weak ASIHTTPRequest* req = _req;
    [req setCompletionBlock:^{
      
        
        SBJsonParser* parser = [[SBJsonParser alloc] init];
        NSData*jsondata = [req responseData];
        NSString*jsonString = [[NSString alloc]initWithBytes:[jsondata bytes]length:[jsondata length]encoding:NSUTF8StringEncoding];
       
        
        completeBlk(jsonString );
    }];
    
    [req setFailedBlock:^{
        NSError* error = [req error];
        
        
        failBlk(error);
    }];
    
    [req startAsynchronous];
}

- (void)onCloseChangePasswordTap:(UITapGestureRecognizer *)recognizer {
    UIButton* btn = (UIButton*) recognizer.view;
    [btn.superview removeFromSuperview];
}

- (void)onChannelTap:(UIView *)view {
    
    if(isMenushowing==FALSE){
    
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        channelView* video = (channelView*) view;
    if ([video class] == [channelView class]){
        void(^urlBlock)(NSString*)  = ^(NSString * url) {
            
            SecondPageViewController * secondPageViewController= [[SecondPageViewController alloc] initWithNibName:@"SecondPageViewController" bundle:nil];
            [self attachEventToSecondPageVC:secondPageViewController];
            secondPageViewController.channelData = video.channelData;
            secondPageViewController.channelURL = url;//@"http://27.115.50.133/cloudtv/yunshi1/yunshi1.m3u8";//
            [self SecondPage:secondPageViewController];
            [MBProgressHUD hideHUDForView:self.view animated:YES];
            
        };
        
        [self getLiveURLOfChannel:video.channelData.resourcesEndpoint WhenComplete:urlBlock OrFail:^(NSError * err) {
            
            
            
            NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
            NSString * message;
            
            switch (err.code) {
                case 3:
                    message= @"用户信息错误，请致电96877咨询(E5202)";
                    if([userDefault objectForKey:@"messages_message"]){
                        NSDictionary * messageReportDic=[userDefault objectForKey:@"messages_message"];
                        if([messageReportDic objectForKey:@"E5202"]){
                            NSDictionary * messageDic=[messageReportDic objectForKey:@"E5202"];
                            message=[messageDic objectForKey:@"message"];
                        }
                    }
                    break;
                    
                default:
                    message= @"节目无法播放（E5104)";
                    if([userDefault objectForKey:@"messages_message"]){
                        NSDictionary * messageReportDic=[userDefault objectForKey:@"messages_message"];
                        if([messageReportDic objectForKey:@"E5104"]){
                            NSDictionary * messageDic=[messageReportDic objectForKey:@"E5104"];
                            message=[messageDic objectForKey:@"message"];
                        }
                    }
                    break;
            }
            [self showAlert:@"提示" :message ];
            [MBProgressHUD hideHUDForView:self.view animated:YES];
        }];
      
   
    }
    }
    else
    {
        [UIView animateWithDuration:0.2f
                              delay:0.0f
                            options:UIViewAnimationOptionCurveEaseOut
                         animations:^
         {
             
             CGRect frame = currentMenuView.frame;
             frame.origin.x = frame.origin.x - frame.size.width;
             currentMenuView.frame = frame;
         }completion:nil];
        isMenushowing=FALSE;
        [self.removeMenuBtn removeFromSuperview];
        [self.MainView setFrame:CGRectMake(0, 0, self.MainView.frame.size.width, self.MainView.frame.size.height)];
    }

}
- (void)onVideoTap:(UIView *)view {
    
    if(isMenushowing==FALSE)
    {
    
     [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    filmvideosView* video = (filmvideosView*) view;

    
    if ([video class] == [filmvideosView class]){
		
        if(video.videoData.getplayUrl!=nil)
        {
            
         
            void(^backBlock)(NSString*)  = ^(NSString * backinfo) {
               
                
                if(![backinfo isEqualToString:@"1111"])
                {
                    
                    
                    NSString *urlPre=[[ Constant getBaseIP] stringByAppendingString:@"/"];
                    if([backinfo hasPrefix:@"/"]==1) urlPre=[ Constant getBaseIP];
                    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString: [urlPre stringByAppendingString:  backinfo ]]];
                    
                    NSString* userID = @"test";
                    
                    NSString* date;
                    NSDateFormatter* formatter = [[NSDateFormatter alloc]init];
                    
                    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss.SSS"];      //毫秒
                    date = [formatter stringFromDate:[NSDate date]];
                    
                    
                    [request setValue:userID forHTTPHeaderField:@"X-user-id"];
                    [request setValue:date forHTTPHeaderField:@"X-Time"];
                    
                    
                    UITapGestureRecognizer *singleFingerTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onCloseChangePasswordTap:)];
                    
                    UIWebView* web = [[UIWebView alloc] initWithFrame:CGRectInset(self.view.frame, 0, 0)];
                    
                    
                    [web loadRequest:request];
                    web.scrollView.bounces = NO;
                    web.delegate= self;
                    web.scalesPageToFit= YES;
                    web.tag=2;//To test 
                    [self.view addSubview:[self getWebView:web AndFrame:self.view.frame OnClose:singleFingerTap]];
                    [MBProgressHUD hideHUDForView:self.view animated:YES];
                }else {
                 
                    allowNext=NO;
                    self.videoPlayer = [[VideoPlayerViewController alloc] initWithContentURL:[NSURL URLWithString:[video.videoData.getplayUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
                    self.videoPlayer.tvseries_id=video.videoData.getcont_tvseries_id;
                    self.videoPlayer.tvseries_playUrl=video.videoData.getplayUrl;
                    self.videoPlayer.tvseries_Order=@"0";
                    self.videoPlayer.videoData=video.videoData;
                    self.videoPlayer.ChannelDetaildelegate=self;
                    
                    __weak MainViewController *weakSelf= self;
                    self.videoPlayer.onDisappearListener = ^(MPMoviePlayerViewController* ctrl){
                        [weakSelf dispatchBreakEvent];
                    };
                    
                    [self.videoPlayer.moviePlayer prepareToPlay];
                    [self.videoPlayer.moviePlayer setUseApplicationAudioSession:NO];
                    [self.videoPlayer.moviePlayer setShouldAutoplay:YES];
                    [self.videoPlayer.moviePlayer setControlStyle:2];
                    
                    
                    [self presentModalViewController:self.videoPlayer animated:NO];
                    
                    
                  
                    
                    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(videoPlayerItemDone:) name:MPMoviePlayerDidExitFullscreenNotification object:self.videoPlayer];
                    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(videoPlayerItemStateChanged:) name:MPMoviePlayerPlaybackStateDidChangeNotification object:self.videoPlayer.moviePlayer];
                     [MBProgressHUD hideHUDForView:self.view animated:YES];

                }
               
            };
           if([video.videoData.getcont_program intValue]!=0) [self HavePerToAccVod:video.videoData WhenComplete:backBlock OrFail:^(NSError * err) {;}];
           else {
               
               allowNext=NO;
               self.videoPlayer = [[VideoPlayerViewController alloc] initWithContentURL:[NSURL URLWithString:[video.videoData.getplayUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
               self.videoPlayer.tvseries_id=video.videoData.getcont_tvseries_id;
               self.videoPlayer.tvseries_playUrl=video.videoData.getplayUrl;
               self.videoPlayer.tvseries_Order=@"0";
               self.videoPlayer.videoData=video.videoData;
               self.videoPlayer.ChannelDetaildelegate=self;
               
               __weak MainViewController *weakSelf= self;
               self.videoPlayer.onDisappearListener = ^(MPMoviePlayerViewController* ctrl){
                   [weakSelf dispatchBreakEvent];
               };
               
               [self.videoPlayer.moviePlayer prepareToPlay];
               [self.videoPlayer.moviePlayer setUseApplicationAudioSession:NO];
               [self.videoPlayer.moviePlayer setShouldAutoplay:YES];
               [self.videoPlayer.moviePlayer setControlStyle:2];
               
               
               [self presentModalViewController:self.videoPlayer animated:NO];
               
               
              
               
               [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(videoPlayerItemDone:) name:MPMoviePlayerDidExitFullscreenNotification object:self.videoPlayer];
               [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(videoPlayerItemStateChanged:) name:MPMoviePlayerPlaybackStateDidChangeNotification object:self.videoPlayer.moviePlayer];
               
                [MBProgressHUD hideHUDForView:self.view animated:YES];
           }
       

    }
        else {
            
            
             [MBProgressHUD hideHUDForView:self.view animated:YES];
            
            ;//[self showAlert:@"提示" :@"节目播放URL为nil"];
        }
    }
  }
    else{
        [UIView animateWithDuration:0.2f
                              delay:0.0f
                            options:UIViewAnimationOptionCurveEaseOut
                         animations:^
         {
             
             CGRect frame = currentMenuView.frame;
             frame.origin.x = frame.origin.x - frame.size.width;
             currentMenuView.frame = frame;
         }completion:nil];
        [self.MainView setFrame:CGRectMake(0, 0, self.MainView.frame.size.width, self.MainView.frame.size.height)];
        isMenushowing=FALSE;
        [self.removeMenuBtn removeFromSuperview];
    
    }
    
}


- (void)videoPlayerItemDone:(NSNotification *)notification {
    
    
    
    [self dispatchBreakEvent];
    
}
- (void)dispatchBreakEvent {
    if(!allowNext) {
        if (self.videoPlayer != nil && !self.videoPlayer.ended){
     
        [self.videoPlayer.moviePlayer.view removeFromSuperview];
        [self dismissViewControllerAnimated:NO completion:nil];
        [self dismissViewControllerAnimated:YES completion:nil];
        
         allowNext=NO;
        
	}
  }
   
}


- (void)filterCategories {
    NSMutableArray *idleImages = [NSMutableArray array];
    for (NSUInteger i = 1; i<=60; i++) {
        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"dropdown_anim__000%zd", i]];
        [idleImages addObject:image];
    }
    // 设置即将刷新状态的动画图片（一松开就会刷新的状态）
    NSMutableArray *refreshingImages = [NSMutableArray array];
    for (NSUInteger i = 1; i<=3; i++) {
        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"dropdown_loading_0%zd", i]];
        [refreshingImages addObject:image];
    }
    // 设置回调（一旦进入刷新状态，就调用target的action，也就是调用self的loadNewData方法）
    MJRefreshGifHeader *header = [MJRefreshGifHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadNewData)];
    // 设置普通状态的动画图片
    [header setImages:idleImages forState:MJRefreshStateIdle];
    // 设置即将刷新状态的动画图片（一松开就会刷新的状态）
    [header setImages:refreshingImages forState:MJRefreshStatePulling];
    // 设置正在刷新状态的动画图片
    [header setImages:refreshingImages forState:MJRefreshStateRefreshing];
    // 设置header
    self.scrollView.header = header;
    
    MJRefreshAutoGifFooter *footer = [MJRefreshAutoGifFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreData)];
    
    // 设置刷新图片
    [footer setImages:refreshingImages forState:MJRefreshStateRefreshing];
    
    // 设置尾部
    self.scrollView.footer = footer;
    if(self.scrollView != nil) {
        NSArray *subviews =[self.scrollView subviews];
        for (int i = 0, l = [subviews count]; i < l; i++) {
            UIView* channelUIView = [subviews objectAtIndex:i];
            [channelUIView removeFromSuperview];
        }
    }
  
     CloudTviCategoryItem* categoryData=(CloudTviCategoryItem*)[self.categoryArray objectAtIndex:categoryid];
          
    
                
                if([categoryData.getCol_action isEqualToString:@"vod"])
                {
                    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
                   
                    ASIHTTPRequest * _req= [ASIHTTPRequest requestWithURL:[NSURL URLWithString:[categoryData.getCol_resource stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
                    
                    __weak ASIHTTPRequest* req = _req;
                    [req setCompletionBlock:^{
                        SBJsonParser* parser = [[SBJsonParser alloc] init];
                       
                        NSData*jsondata = [req responseData];
                        NSString*jsonString = [[NSString alloc]initWithBytes:[jsondata bytes]length:[jsondata length]encoding:NSUTF8StringEncoding];
                        
                        if (jsonString != nil){
                            if([jsonString hasPrefix:@"["])
                            {
                            NSArray* data = [parser objectWithString:jsonString];
                           
                            if(data){
                               
                                for (int i = 0, l = [data count] - 1; i <= l; i++){
                                    NSDictionary* video = [data objectAtIndex:i];
                                 
                                    
                                    VideoDataItem* videoData = [[VideoDataItem alloc] init];
                                    videoData.cid=[NSString stringWithFormat:@"%@",[video objectForKey:@"cont_id"]];
                                    videoData.description=[video objectForKey:@"cont_description"];
                                    videoData.playUrl=[video objectForKey:@"cont_play"];//@"http://211.144.83.147/cloudtv/video/83/83.m3u8";//
                                    videoData.picUrl=[video objectForKey:@"cont_pic"];
                                    videoData.cont_column=[video objectForKey:@"cont_column_id"];
                                    videoData.cont_program=[NSString stringWithFormat:@"%@",[video objectForKey:@"cont_program_id"]];
                                    videoData.cont_tvseries_id=[video objectForKey:@"cont_tvseries_id"];
                                    [self addfilmvideos:videoData];
                                
                                }
                                
                                
                             }
                                
                            }
                            else{
                              
                                [self showAlert:@"提示" :@"Error  JSON Data"];
                                
                            }
                            
                            
                        }
                        
                       
                        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
                    }];
                    [req setFailedBlock:^{
                        NSError* error = [req error];
                        
                           [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
                        
                    }];
                    [req startAsynchronous];
                  
                }
                else {
                
                    [self loadAllLiveChannel];
                
                }
           
    
         
    
   
    
    
  
}
- (void)showAlert:(NSString *)title :(NSString *) msg {
    alert = [[UIAlertView alloc] initWithTitle:title
                                       message:msg
                                      delegate:self
                             cancelButtonTitle:@"知道了"
                             otherButtonTitles:nil];
    [alert show];
    
    
    alert.tag=1;
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    alertView.tag=0;
   
}

- (void)loadAllLiveChannel {
    NSMutableArray *idleImages = [NSMutableArray array];
    for (NSUInteger i = 1; i<=60; i++) {
        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"dropdown_anim__000%zd", i]];
        [idleImages addObject:image];
    }
    // 设置即将刷新状态的动画图片（一松开就会刷新的状态）
    NSMutableArray *refreshingImages = [NSMutableArray array];
    for (NSUInteger i = 1; i<=3; i++) {
        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"dropdown_loading_0%zd", i]];
        [refreshingImages addObject:image];
    }
    // 设置回调（一旦进入刷新状态，就调用target的action，也就是调用self的loadNewData方法）
    MJRefreshGifHeader *header = [MJRefreshGifHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadNewData)];
    // 设置普通状态的动画图片
    [header setImages:idleImages forState:MJRefreshStateIdle];
    // 设置即将刷新状态的动画图片（一松开就会刷新的状态）
    [header setImages:refreshingImages forState:MJRefreshStatePulling];
    // 设置正在刷新状态的动画图片
    [header setImages:refreshingImages forState:MJRefreshStateRefreshing];
    // 设置header
    self.scrollView.header = header;
    MJRefreshAutoGifFooter *footer = [MJRefreshAutoGifFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreData)];
    
    // 设置刷新图片
    [footer setImages:refreshingImages forState:MJRefreshStateRefreshing];
    
    // 设置尾部
    self.scrollView.footer = footer;
    if(self.scrollView != nil){
        NSArray *subviews =[self.scrollView subviews];
        for (int i = 0, l = [subviews count]; i < l; i++){
            UIView* channelUIView = [subviews objectAtIndex:i];
            [channelUIView removeFromSuperview];
        }
    }
    
    
    CloudTviCategoryItem* categoryData=(CloudTviCategoryItem*)[self.categoryArray objectAtIndex:categoryid];

  
    NSArray *array = [categoryData.getCol_resource  componentsSeparatedByString:@"/api/v2/live/channels.json"]; //从字符/api/v2/live/channels.json中分隔成2个元素的数组
    
   if([array count]>1) self.LiveHostName=array[0];
   else   {[self showAlert:@"提示" :@"Error  Col_resource Data"];  return;}
  
   [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    ASIHTTPRequest * _req= [ASIFormDataRequest requestWithURL:[NSURL URLWithString:  [categoryData.getCol_resource stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
 
    
    __weak ASIHTTPRequest* req = _req;
 
    [req setCompletionBlock:^{
        SBJsonParser* parser = [[SBJsonParser alloc] init];
    NSData*jsondata = [req responseData];
    NSString*jsonString = [[NSString alloc]initWithBytes:[jsondata bytes]length:[jsondata length]encoding:NSUTF8StringEncoding];
        
        if (jsonString != nil){
            
           
            if([jsonString hasPrefix:@"{"])
            {
                NSDictionary* data = [parser objectWithString:jsonString];
                if([data objectForKey:@"channels"])//[jsonString rangeOfString:@"\"channels\":["].location != NSNotFound
                {
                    
                    NSArray* channelsArr = [data objectForKey:@"channels"];
                    
                    if(channelsArr.count==0 ){
                        [self showAlert:@"提示" :@"暂无频道信息，请再次刷新（按钮）"];
                        
                        UIButton * refreshChannelBtn=[UIButton buttonWithType:UIButtonTypeCustom];
                        refreshChannelBtn.frame= CGRectMake(58, 100, 204, 62);
                        [refreshChannelBtn setImage:[UIImage imageNamed:@"iphonerefresh-btn.png"] forState:UIControlStateNormal];
                        [refreshChannelBtn addTarget:self action:@selector(onTapRefreshChannel:) forControlEvents:UIControlEventTouchUpInside];
                        [self.scrollView addSubview:refreshChannelBtn];
                        
                    }
                    else {
                        
                        for (int i = 0, l = [channelsArr count] - 1; i <= l; i++){
                            NSDictionary* channel = [channelsArr objectAtIndex:i];
                            OCNChannelData* channelData = [[OCNChannelData alloc] init];
                            channelData.channelID=[channel objectForKey:@"id"];
                            channelData.upcode = [channel objectForKey:@"upcode"];
                            channelData.num = [channel objectForKey:@"num"];
                            channelData.name = [channel objectForKey:@"name"];
                            channelData.updatedAt = [channel objectForKey:@"updated_at"];
                            channelData.logoURL = [channel objectForKey:@"logo_url"];
                            channelData.programsEndpoint = [channel objectForKey:@"programs_endpoint"];
                            channelData.resourcesEndpoint =[[self.LiveHostName stringByAppendingString:@"/api/v2"] stringByAppendingString:[channel objectForKey:@"resources_endpoint"]];
                            
                            channelData.categories = [channel objectForKey:@"categories"] ;
                            channelData.resources = [channel objectForKey:@"resources"];
                            NSDictionary* logurls  = [channel objectForKey:@"logo_urls"];
                            
                            channelData.cloudtvsomeLogoUrl=[logurls objectForKey:@"default"];
                            [self addChannel:channelData];
                          
                            
                        }
                         [self  reloadNowPlaying];
                    }
                    
                 
                  
                 
                    
                }
            }
            else
            {
                [self showAlert:@"提示" :@"Error  JSON Data"];
          
            }
            
        }
              [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
    [req setFailedBlock:^{
        NSError* error = [req error];
       
              [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
    [req startAsynchronous];
    
}

#pragma mark 上拉加载更多数据
- (void)loadMoreData
{
    NSLog(@"加载更多数据");
}

#pragma mark - 数据处理相关
#pragma mark 下拉刷新数据
- (void)loadNewData
{
    // 1.添加数据
    NSLog(@"添加数据");
    
    // 2.模拟2秒后刷新表格UI（真实开发中，可以移除这段gcd代码）
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(MJDuration * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // 刷新表格
        //[self.tableView reloadData];
        
        // 拿到当前的下拉刷新控件，结束刷新状态
        //[self.tableView.header endRefreshing];
    });
}
- (IBAction) onTapRefreshChannel:(id) sender{
    
    [self loadAllLiveChannel];
}

- (void)addChannel:(OCNChannelData*) channel{
    int index = [[self.scrollView subviews] count];
    
    NSArray *nibContents = [[NSBundle mainBundle] loadNibNamed:@"channelView"
                                                         owner:self
                                                       options:nil];
    
    __weak channelView *myView = [nibContents objectAtIndex:0];
    myView.channelData = channel;
	

    AsyncImageView* icon = (AsyncImageView*) [myView viewWithTag:filmchannelIconTag];
   
    NSURL* url = [NSURL URLWithString:[channel.logoURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    [icon loadImageFromURL:url];
    
    
    UILabel* channelName = (UILabel*) [myView viewWithTag:filmchannelNameTag];
    channelName.text = channel.name;
    
	
 
    myView.frame = CGRectMake(xOffset/2, 90 * index, self.view.frame.size.width, 90);
    
    
    __weak MainViewController *weakSelf= self;
    myView.onChannelViewTapListener = ^(UIView* view){
       
    [weakSelf onChannelTap:view];
        
	};
    
   
        
    [myView setWatchingText:@"暂无节目信息"];
  
    
    [myView setWillWatchText:@"暂无节目信息"];
    [self.scrollView addSubview:myView];
    [self checkScrollViewHeight];
}


- (void) getLiveURLOfChannel: (NSString*) resourceURL  WhenComplete:(void (^)(NSString*)) completeBlk OrFail: (void (^)(NSError*)) failBlk{
    
    //android getChannelUrl
    NSURL* url = [NSURL URLWithString:[resourceURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
    ASIFormDataRequest* _req = [ASIFormDataRequest requestWithURL:url];
    
    
    __weak ASIHTTPRequest* req = _req;
    [req setCompletionBlock:^{
      
        
        SBJsonParser* parser = [[SBJsonParser alloc] init];
        NSData*jsondata = [req responseData];
        NSString*jsonString = [[NSString alloc]initWithBytes:[jsondata bytes]length:[jsondata length]encoding:NSUTF8StringEncoding];
       
        NSDictionary* data = [parser objectWithString:jsonString];
        
        
        NSString* ret = @"";
        NSArray* resources = [data objectForKey:@"resources"];
        for (int i = 0, l = [resources count]; i < l; i++){
            NSDictionary* resource = [resources objectAtIndex:i];
            NSString* type = [resource objectForKey:@"type"];
            if ([type isEqualToString:@"hls"]){
                ret = [resource objectForKey:@"url"];
                break;
            }
        }
        //ret=@"http://211.144.83.147/cloudtv/video/83/83.m3u8";
        
        completeBlk(ret);
    }];
    [req setFailedBlock:^{
        NSError* error = [req error];
       
        
        failBlk(error);
    }];
    [req startAsynchronous];
    
}




- (void)viewDidLoad
{
    [super viewDidLoad];
   
    MinPlayTime=10;
    categoryid=-1;
    self.LiveHostName=@"";
    rowWidth = self.view.frame.size.width-20;
    rowHeight = (self.view.frame.size.width-20)*9/16+18;
    [self LoadIPAddress];
    [self loadAllCategories];
    UISwipeGestureRecognizer *recognizer;
    
    recognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeFrom:)];
    
    [recognizer setDirection:(UISwipeGestureRecognizerDirectionRight)];
    
    [[self view] addGestureRecognizer:recognizer];
    
  
   
    
  
    
    
    
    recognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeFrom:)];
    
    [recognizer setDirection:(UISwipeGestureRecognizerDirectionLeft)];
    
    [[self view] addGestureRecognizer:recognizer];
  
   
    isMenushowing=FALSE;
    
   

    
    // Do any additional setup after loading the view from its nib.
}
- (void)LoadIPAddress
{
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    if([userDefault objectForKey:@"BaseIP"] != nil){
        
        [Constant setBaseIP:[NSString stringWithFormat:@"%@",[userDefault objectForKey:@"BaseIP"]]];
        
     
    }
    
   
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
   
}


- (void)viewDidAppear:(BOOL)animated {
  
   
  
    
    
    
    [self.nowPlayingTimer invalidate];
    
    self.nowPlayingTimer = [NSTimer scheduledTimerWithTimeInterval:MinPlayTime*60 target:self selector:@selector(reloadNowPlaying) userInfo:nil repeats:YES];
    
}



- (NSMutableArray*) parseProgramArray: (NSArray*) programs{
    NSMutableArray* ret = [[NSMutableArray alloc] init];
    
    if (programs == nil){
        return ret;
    }
    
    for (int i = 0, l = [programs count] - 1; i <= l; i++){
        NSDictionary* program = [programs objectAtIndex:i];
        OCNProgramData* programData = [self parseProgramData:program];
        [ret addObject:programData];
    }
    
    return ret;
}
- (OCNProgramData*) parseProgramData: (NSDictionary*) program{
    OCNProgramData* programData = [[OCNProgramData alloc] init];
    if (program != nil){
        programData.programID = [program objectForKey:@"id"];
        programData.updatedAt = [program objectForKey:@"updated_at"];
        programData.broadcastStartAt = [program objectForKey:@"broadcast_start_at"];
        programData.broadcastEndAt = [program objectForKey:@"broadcast_end_at"];
        programData.fullTitle = [program objectForKey:@"full_title"];
        programData.description = [program objectForKey:@"description"];
      
       
        programData.chanelID=chanelID;
        
    }
    
    
    return programData;
}
- (void) nowPlaying: (NSMutableArray*) channels WhenComplete:(void (^)(NSMutableArray*)) completeBlk OrFail: (void (^)(NSError*)) failBlk{
 
    
    NSURL* url = [NSURL URLWithString:[[self.LiveHostName stringByAppendingString:NOWPLAY_URLLast] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    ASIHTTPRequest* _req = [ASIHTTPRequest requestWithURL:url];
   
    
    
    
    __weak ASIHTTPRequest* req = _req;
 
  
    [req setCompletionBlock:^{
        
        
        
        
        SBJsonParser* parser = [[SBJsonParser alloc] init];
        NSData*jsondata = [req responseData];
        NSString*jsonString = [[NSString alloc]initWithBytes:[jsondata bytes]length:[jsondata length]encoding:NSUTF8StringEncoding];
        NSDictionary* data = [parser objectWithString:jsonString ];
          NSMutableArray* localNowprograms = [[NSMutableArray alloc] init];
       if(data){
     
        NSArray* playingList = [data objectForKey:@"playing_list"];
        for (int i = 0, l = [playingList count] - 1; i <= l; i++){
            NSDictionary* channel = [playingList objectAtIndex:i];
       
            OCNChannelProgramData* channelProgramData = [[OCNChannelProgramData alloc] init];
            
          
            
            channelProgramData.pastProgramData = [self parseProgramArray:[channel objectForKey:@"past"]];
            channelProgramData.futureProgramData = [self  parseProgramArray:[channel objectForKey:@"future"]];
            channelProgramData.nowProgramData = [self parseProgramData:[channel objectForKey:@"now"]];
            NSDictionary* channelData =[channel objectForKey:@"channel"];
            channelProgramData.channelID = [channelData objectForKey:@"id"];
            channelProgramData.name = [channelData objectForKey:@"name"];
            chanelID=channelProgramData.channelID;;
               
            [localNowprograms addObject:channelProgramData];
            
         }
       }
        
        completeBlk(localNowprograms);
    }];
    [req setFailedBlock:^{
        NSError* error = [req error];
        
      
        
        failBlk(error);
    }];
    [req startAsynchronous];

}

- (void)reloadNowPlaying{
  
   
    
    
    
    if(self.scrollView != nil){
        NSArray *subviews =[self.scrollView subviews];
        
        NSMutableArray* channels = [[NSMutableArray alloc] init];
        
        NSMutableDictionary* channelMap = [[NSMutableDictionary alloc] init];
        
        for (int i = 0, l = [subviews count]; i < l; i++){
            UIView* channelUIView = [subviews objectAtIndex:i];
            
            if ([channelUIView class] == [channelView class]){
                channelView* channel = (channelView*) channelUIView;
                OCNChannelData* channelData = channel.channelData;
              
                NSString* cid = [channelData getchannelID];
                [channels addObject:cid];
                [channelMap setValue:channel forKey:cid];
            }
        }
        
       
        
       
        //OCNChannelProgramData
        NSMutableArray* emptychannels = [[NSMutableArray alloc] init];
        
        [self nowPlaying:emptychannels  WhenComplete:^(NSMutableArray * programDataList) {
       

            for (int i = 0, l = [programDataList count]; i < l; i++){
                OCNChannelProgramData* programData = [programDataList objectAtIndex:i];
              
                channelView* channel = [channelMap objectForKey:[programData getChannelID]];
                if (channel != nil){
                    
                    
                    
                    if(programData.nowProgramData.fullTitle){
                    
                        [channel setWatchingText:programData.nowProgramData.fullTitle];
                    }
                    
                    
                
                    
                    if ([programData.futureProgramData count] > 0){
                        NSString* futureTitle = [(OCNProgramData*) [programData.futureProgramData objectAtIndex:0] fullTitle];
                        

                        [channel setWillWatchText:futureTitle];
                        int MinW= [[[[programData.futureProgramData objectAtIndex:0] getFormattedBroadcastStartAt] substringWithRange:NSMakeRange(3,2)] intValue]+[[[[programData.futureProgramData objectAtIndex:0] getFormattedBroadcastStartAt] substringWithRange:NSMakeRange(0,2)] intValue]*60;
                        
                        NSString* date;
                        NSDateFormatter* formatter = [[NSDateFormatter alloc]init];
                        
                        [formatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ssZ"];
                        date = [formatter stringFromDate:[NSDate date]];
                       
                        int MinN=[[date substringWithRange:NSMakeRange(14,2)] intValue]+[[date substringWithRange:NSMakeRange(11,2)] intValue]*60;
                      
                        
                        if(MinPlayTime>(MinW-MinN)&&((MinW-MinN)>=3))
                        {
                            MinPlayTime=MinW-MinN;
                            
                            [self.nowPlayingTimer invalidate];
                            
                            self.nowPlayingTimer = [NSTimer scheduledTimerWithTimeInterval:MinPlayTime*60 target:self selector:@selector(reloadNowPlaying) userInfo:nil repeats:YES];
                        }
                        
                    }
                }
            }
        }
                  OrFail:^(NSError * err) {
                      
                  }];
    }
    
}
- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
    [self.nowPlayingTimer invalidate];
    
 
    if(alert.tag==1)
    {
        
        [alert dismissWithClickedButtonIndex:0 animated:YES];
        alert.tag=0;
        
    }
}

- (void)viewDidDisappear:(BOOL)animated {
    
  [super viewDidDisappear:animated];
    
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return UIInterfaceOrientationIsPortrait(interfaceOrientation);
    } else {
        return UIInterfaceOrientationIsLandscape(interfaceOrientation);
    }
}

- (NSUInteger)supportedInterfaceOrientations {
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return UIInterfaceOrientationMaskPortrait;
    } else {
        return UIInterfaceOrientationMaskLandscape;
    }
}

- (IBAction)handleSwipeFrom:(UISwipeGestureRecognizer *)sender {
    
     CGPoint point = [sender locationInView:self.view];
    if (sender.direction==UISwipeGestureRecognizerDirectionRight ){
        
     
        
      
        if(isMenushowing==FALSE){
            if(point.x<self.view.frame.size.width/6){
                NSArray *nibContents = [[NSBundle mainBundle] loadNibNamed:@"MenuView"
                                                             owner:self
                                                           options:nil];
        
                currentMenuView = [nibContents objectAtIndex:0];
                currentMenuView.delegate=self;
                currentMenuView.frame = CGRectMake(-228, 0, rowWidthMenu, self.view.frame.size.height);
                [currentMenuView updateIpEdittext];
                [currentMenuView loadMenuItem];
                [UIView animateWithDuration:0.2f
                                      delay:0.0f
                                    options:UIViewAnimationOptionCurveEaseOut
                                 animations:^
                 {
                     
                     CGRect frame = currentMenuView.frame;
                     frame.origin.x = frame.origin.x + frame.size.width;
                     currentMenuView.frame = frame;
                 }completion:nil];
               
                [self.MainView setFrame:CGRectMake(228, 0, self.MainView.frame.size.width, self.MainView.frame.size.height)];
                [self.view addSubview:currentMenuView];
                isMenushowing=TRUE;
                CGRect frameRemove = CGRectMake(rowWidthMenu, 0, self.view.frame.size.width, self.view.frame.size.height);
                self.removeMenuBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
                self.removeMenuBtn.backgroundColor = [UIColor clearColor];
                self.removeMenuBtn.frame = frameRemove;
                [self.removeMenuBtn addTarget:self action:@selector(removeMenuAction) forControlEvents:UIControlEventTouchUpInside];
                [self.view addSubview:self.removeMenuBtn];
               
                
            }
            else{
                if(categoryid>=1){
                    
                    categoryid=categoryid-1;
                    [self slideCategory];
                }
            }
        }
      
        
    }
    else if (sender.direction==UISwipeGestureRecognizerDirectionLeft){
      
        if(isMenushowing){
            [UIView animateWithDuration:0.2f
                                  delay:0.0f
                                options:UIViewAnimationOptionCurveEaseOut
                             animations:^
             {
                 
                 CGRect frame = currentMenuView.frame;
                 frame.origin.x = frame.origin.x - frame.size.width;
                 currentMenuView.frame = frame;
             }completion:nil];
            isMenushowing=FALSE;
            [self.removeMenuBtn removeFromSuperview];
            [self.MainView setFrame:CGRectMake(0, 0, self.MainView.frame.size.width, self.MainView.frame.size.height)];
        }
        else{
            if(categoryid+1<[self.categoryArray count]){
                categoryid=categoryid+1;
            [self slideCategory];
      
            }
        }
    }
    
}


- (IBAction)removeMenuAction
{
 
    
    if(isMenushowing){
      
        [UIView animateWithDuration:0.2f
                              delay:0.0f
                            options:UIViewAnimationOptionCurveEaseOut
                         animations:^
         {
             
             CGRect frame = currentMenuView.frame;
             frame.origin.x = frame.origin.x - frame.size.width;
             currentMenuView.frame = frame;
         }completion:nil];
        isMenushowing=FALSE;
        [self.removeMenuBtn removeFromSuperview];
        [self.MainView setFrame:CGRectMake(0, 0, self.MainView.frame.size.width, self.MainView.frame.size.height)];
    }
}

@end
