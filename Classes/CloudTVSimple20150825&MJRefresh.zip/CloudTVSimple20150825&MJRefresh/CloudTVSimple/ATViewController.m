//
//  ATViewController.m
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import "ATViewController.h"

@interface ATViewController ()

@end

@implementation ATViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    //if ([self respondsToSelector:@selector(setEdgesForExtendedLayout:)]) {
    //    self.edgesForExtendedLayout = UIRectEdgeBottom;
    //    self.extendedLayoutIncludesOpaqueBars = NO;
    //}
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
   
}

- (void)viewDidLayoutSubviews {
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7) {
        CGRect viewBounds = self.view.superview.bounds;
        NSLog(@"%@", NSStringFromCGRect(viewBounds));
        CGFloat topBarOffset = self.topLayoutGuide.length;
        self.view.frame = CGRectMake(0, topBarOffset, viewBounds.size.width, viewBounds.size.height - topBarOffset);
        self.view.clipsToBounds = YES;
    }
}

- (void)didReceiveMemoryWarning {
    [[NSURLCache sharedURLCache] removeAllCachedResponses];
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
