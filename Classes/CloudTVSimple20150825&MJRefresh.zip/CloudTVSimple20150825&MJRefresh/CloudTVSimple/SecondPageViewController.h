//
//  SecondPageViewController.h
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PlayerView.h"
#import <AVFoundation/AVFoundation.h>
#import <MediaPlayer/MediaPlayer.h>
#import "OCNChannelData.h"
#import "PlayPauseToggleButton.h"
#import "Toucher.h"

#import "ATViewController.h"


@class MainViewController;
@interface SecondPageViewController : ATViewController<UIGestureRecognizerDelegate,UIAlertViewDelegate>{
    int switchNum;
    int switchPlayAndStopNum;
    
	BOOL showPlaying;
	BOOL stopped;
	
    float prevVolume;
    BOOL soundOn;
   
    UIAlertView *alert;
}

typedef void (^OnIPhonePushBtnTapListener)();
typedef void (^OnIPhoneFinishPushBtnTapListener)();

@property (nonatomic) IBOutlet UIButton *switchBtn;
@property (nonatomic) IBOutlet UIButton *soundOnBtn;
@property (nonatomic) IBOutlet UIButton *soundOffBtn;
@property (nonatomic) IBOutlet UILabel *nameLabel;
@property (nonatomic) IBOutlet UILabel *channelNameLabel;

@property (nonatomic) IBOutlet UIImageView *volumeBarBG;
@property (nonatomic) IBOutlet UIImageView *volumeBar;
@property (nonatomic) IBOutlet UIImageView *volumeBarThumb;
@property (nonatomic) IBOutlet Toucher *volumeToucher;

@property (nonatomic) IBOutlet PlayerView *playerView;
@property (nonatomic) IBOutlet PlayerView *playerViewContainer;
@property (nonatomic) IBOutlet UIButton *playBtn;
@property (nonatomic) IBOutlet UIButton *pauseBtn;

@property (nonatomic) IBOutlet UIView *topPanel;
@property (nonatomic) IBOutlet UIView *ctrlPanel;
@property (nonatomic) BOOL isShowPanel;
@property (weak, nonatomic) IBOutlet UIButton *switchPushBtn;

@property (nonatomic, strong) OnIPhonePushBtnTapListener onPushBtnTapListener;
@property (nonatomic, strong) OnIPhoneFinishPushBtnTapListener onFinishPushBtnTapListener;

@property (nonatomic, strong) OCNChannelData *channelData;
@property (nonatomic, strong) NSString *channelURL;
@property (nonatomic, strong) NSString *channelID;
@property (nonatomic, strong) AVPlayer *player;
@property  AVPlayerItem *playerItem;

@property (nonatomic) BOOL isAppearing;
@property (nonatomic, strong) NSURL *fileURL;
@property (nonatomic, strong) MPMoviePlayerViewController *playerViewController;

@property (nonatomic, strong) NSTimer *fullPanelTimer;

@property (nonatomic, assign) MainViewController *firstPageViewController;




- (void)loadVideo;
- (void)syncVolumeUI:(float) volume;
- (void)loadVideoFromURL;

- (int)getCurrentChannelID;

- (IBAction)BackBtn:(id)sender;
- (IBAction)onTapPlayPauseBtn:(id) sender;
- (IBAction)onTapStopBtn:(id) sender;
- (IBAction)onTapSoundOn:(id)sender;
- (IBAction)onTapSoundOff:(id)sender;
- (IBAction)onTapFullScreen:(id)sender;
- (void)movieFinishedCallback:(NSNotification *) aNotification;
- (void)onFullPanelTap:(UITapGestureRecognizer *)recognizer;
- (void)hasActivity;

@end
