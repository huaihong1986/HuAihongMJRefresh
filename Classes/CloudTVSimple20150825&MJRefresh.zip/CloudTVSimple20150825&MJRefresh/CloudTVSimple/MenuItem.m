//
//  MenuItem.m
//  CloudTvSimple
//
//  Created by Hu on 06/02/15.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "MenuItem.h"

@implementation MenuItem
@synthesize imageleftView,imagerightView,MiddleName,BgView;
@synthesize onMenuItemTapListener;
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void) touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
	if (self.onMenuItemTapListener){
		self.onMenuItemTapListener(self);
	}
}


@end
