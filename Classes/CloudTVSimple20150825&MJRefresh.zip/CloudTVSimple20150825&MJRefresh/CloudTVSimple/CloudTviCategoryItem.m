//
//  CloudTviCategoryItem.m
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import "CloudTviCategoryItem.h"

@implementation CloudTviCategoryItem
@synthesize col_action,col_id,col_name,col_resource;

- (NSString *)getCol_name {
    return self.col_name;
}


- (NSString *)getCol_action {
    return  self.col_action;
}

- (NSString *)getCol_resource {
    return self.col_resource;
}

- (NSString *)getCol_id {
    return self.col_id;
}
@end
