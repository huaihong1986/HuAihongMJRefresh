//
//  OCNChannelProgramData.h
//  CloudTVSimple
//
//  Created by Hu Aihong on 14-11-27.
//  Copyright (c) 2014年 Hu Aihong. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OCNProgramData.h"

@interface OCNChannelProgramData : NSObject

@property (nonatomic) NSString *channelID;
@property (nonatomic) NSString *name;
@property (nonatomic) NSMutableArray *pastProgramData;
@property (nonatomic) OCNProgramData *nowProgramData;
@property (nonatomic) NSMutableArray *futureProgramData;

-(NSString *)getChannelID;

@end
